<?php
include '../asset/config/koneksi.php';

$id = $_GET['id'] ?? '';

$stmt = $koneksi->prepare("
    SELECT 
        dp.*, 
        b.*, 
        o.*
    FROM data_pendaftar dp
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    LEFT JOIN data_ortu o ON dp.id_ortu = o.id_ortu
    WHERE dp.id_pendaftar = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    echo "<script>
            alert('Data tidak ditemukan!');
            window.location.href='data-pendaftar.php';
        </script>";
        exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Cetak Data PPDB</title>
<style>
body {
    font-family: Arial, sans-serif;
    font-size: 12px;
}
h3 {
    text-align: center;
    margin-bottom: 5px;
}
hr {
    margin-bottom: 15px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 15px;
}
td {
    padding: 6px;
    vertical-align: top;
}
.section {
    margin-bottom: 20px;
}
.section-title {
    font-weight: bold;
    background: #f0f0f0;
    padding: 6px;
}
.lampiran td {
    border: 1px solid #000;
}
@media print {
    button {
        display: none;
    }
}

</style>
</head>

<body onload="window.print()">

<h3>FORMULIR PENDAFTARAN PPDB</h3>
<hr>

<!-- DATA SISWA -->
<div class="section">
<div class="section-title">A. DATA CALON SISWA</div>
<table>
<tr><td width="30%">No Pendaftaran</td><td>: <?= $data['no_daftar'] ?></td></tr>
<tr><td>Nama Siswa</td><td>: <?= $data['nama_siswa'] ?></td></tr>
<tr><td>NISN</td><td>: <?= $data['nisn'] ?></td></tr>
<tr><td>Jenis Kelamin</td><td>: <?= $data['gender'] ?></td></tr>
<tr><td>Tempat, Tgl Lahir</td><td>: <?= $data['ttl'] ?></td></tr>
<tr><td>Agama</td><td>: <?= $data['agama'] ?></td></tr>
<tr><td>Alamat</td><td>: <?= $data['alamat'] ?></td></tr>
<tr><td>Asal Sekolah</td><td>: <?= $data['asal_sekolah'] ?></td></tr>
<tr><td>No HP</td><td>: <?= $data['no_hp'] ?></td></tr>
<tr><td>Tanggal Daftar</td><td>: <?= $data['tanggal'] ?></td></tr>
<tr><td>Status</td><td>: <?= $data['status'] ?></td></tr>
</table>
</div>

<!-- DATA ORANG TUA -->
<div class="section">
<div class="section-title">B. DATA ORANG TUA</div>
<table>
<tr><td width="30%">Nama Ayah</td><td>: <?= $data['nama_ayah'] ?></td></tr>
<tr><td>Pendidikan Ayah</td><td>: <?= $data['pendidikan_ayah'] ?></td></tr>
<tr><td>Pekerjaan Ayah</td><td>: <?= $data['pekerjaan_ayah'] ?></td></tr>
<tr><td>No HP Ayah</td><td>: <?= $data['no_hp_ayah'] ?></td></tr>

<tr><td>Nama Ibu</td><td>: <?= $data['nama_ibu'] ?></td></tr>
<tr><td>Pendidikan Ibu</td><td>: <?= $data['pendidikan_ibu'] ?></td></tr>
<tr><td>Pekerjaan Ibu</td><td>: <?= $data['pekerjaan_ibu'] ?></td></tr>
<tr><td>No HP Ibu</td><td>: <?= $data['no_hp_ibu'] ?></td></tr>
</table>
</div>

<!-- LAMPIRAN -->
<div class="section">
<div class="section-title">C. LAMPIRAN BERKAS</div>
<table class="lampiran">
<tr>
    <td>Akta Kelahiran</td>
    <td><?= $data['akta'] ? 'Ada' : 'Tidak Ada' ?></td>
</tr>
<tr>
    <td>Kartu Keluarga</td>
    <td><?= $data['kk'] ? 'Ada' : 'Tidak Ada' ?></td>
</tr>
<tr>
    <td>Ijazah/SKL</td>
    <td><?= $data['ijazah'] ? 'Ada' : 'Tidak Ada' ?></td>
</tr>
<tr>
    <td>KTP Ibu</td>
    <td><?= $data['ktp_ibu'] ? 'Ada' : 'Tidak Ada' ?></td>
</tr>
<tr>
    <td>KTP Ayah</td>
    <td><?= $data['ktp_ayah'] ? 'Ada' : 'Tidak Ada' ?></td>
</tr>
<tr>
    <td>Status Berkas</td>
    <td><?= $data['status_berkas'] ?></td>
</tr>
<tr>
    <td>Catatan</td>
    <td><?= $data['catatan'] ?></td>
</tr>
</table>
</div>

</body>
</html>
