<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

$stmt = $koneksi->prepare("
    SELECT * FROM data_pendaftar dp
    LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    WHERE kp.status_ppdb = 'aktif'
    ORDER BY dp.tanggal DESC
    LIMIT 10
");
$stmt->execute();
$result = $stmt->get_result();

$stmt2 = $koneksi->prepare("SELECT * FROM data_pendaftar dp
	LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
	WHERE kp.status_ppdb = 'aktif'");
$stmt2->execute();
$result2 = $stmt2->get_result();
$jumlah_ppdb = $result2->num_rows;

$stmt3 = $koneksi->prepare("SELECT * FROM data_pendaftar WHERE status='menunggu validasi'");
$stmt3->execute();
$result3 = $stmt3->get_result();
$jumlah_menunggu = $result3->num_rows;

$stmt4 = $koneksi->prepare("SELECT * FROM data_pendaftar WHERE status='diterima'");
$stmt4->execute();
$result4 = $stmt4->get_result();
$jumlah_diterima = $result4->num_rows;

$stmt5 = $koneksi->prepare("SELECT * FROM data_pendaftar WHERE status='ditolak'");
$stmt5->execute();
$result5 = $stmt5->get_result();
$jumlah_ditolak = $result5->num_rows;

// Ambil data jenjang + jumlah pendaftar
$query = "
    SELECT k.jenjang, COUNT(dp.id_kouta) AS total
    FROM kouta_ppdb k
    LEFT JOIN data_pendaftar dp ON k.id_kouta = dp.id_kouta
    GROUP BY k.jenjang
";

$result7 = $koneksi->query($query);

$labels = [];
$values = [];

while ($row = $result7->fetch_assoc()) {
    $labels[] = strtoupper($row['jenjang']);
    $values[] = $row['total'];
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style type="text/css">
body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: #f5f8fb;
}
.profile {
	display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: 0.9em;
    padding: 10px 0px;
    text-transform: capitalize;
    color: rgba(0,0,0,0.6);
}
.profile button {
	width: 50px;
	height: 50px;
	border: none;
	outline-style: none;
	border-radius: 50px;
	background-size: cover;
	margin: 0px 10px;
}
.nama p {
	margin: 0px;
	color: rgba(0,0,0,0.6);
}
.profile a {
	text-decoration: none;
	margin: 0px 10px;
}
.profile a img {
	width: 30px;
}
.profile a img:hover {
	background: rgba(255, 0, 0, 0.13);
    border-radius: 5px;
    transition: 0.5s all;

}

.navbar {
	position: fixed;
	top: 0px;
	bottom: 0px;
	width: 300px;
	transition: 0.5s all;
}
.menu {
	background: #2da8ff;
	color: white;
	border-radius: 25px;
	padding: 10px;
}

.logo img {
	width: 50px;
	margin: 10px 10px;
}
.logo p {
	font-weight: bold;
	color: rgba(0,0,0,0.6);
}

.menu h5 {
	font-size: 0.9em;
	font-weight: normal;
	padding: 10px;
	margin: 0px;
}
.menu a {
	display: flex;
	align-items: center;
	color: white;
	text-decoration: none;
	padding: 10px;
	font-size: 0.9em;
	margin: 5px 0px;
}
.menu a img {
	width: 20px;
}
.menu a p {
	margin: 0px 5px;
}

.dash {
	margin-left: 300px;
	padding: 0px 20px;
	transition: 0.5s all;
}

.btn-menu {
	display: flex;
	align-items: center;
}
.btn-menu button {
	width: 30px;
	height: 30px;
	outline-style: none;
	border: none;
	background: transparent;
}
.btn-menu p {
	margin: 0px 10px;
	font-size: 1.2em;
	color: #2da8ff;
	font-weight: bold;
}

.cards {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 20px;
	padding: 20px;
}

.cards a {
	text-decoration: none;
	padding: 10px 15px;
	background: white;
	border-radius: 5px;
	color: #2da8ff;
}
.cards a:hover {
	transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    transition: 0.5s all;
}

.card {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.card h2 {
	margin: 0px;
	padding: 5px 0px;
	font-size: 1.5em;
}
.card h3 {
	margin: 0px;
	padding: 5px 0px;
	font-size: 0.9em;
}
.card img {
	width: 40px;
}

.konten-tengah {
	display: flex;
	gap: 20px;
	font-size: 0.9em;
	padding: 0px 20px;
	border-radius: 5px;
}

.tabel-pendaftar {
	padding: 20px;
	width: 60%;
	height: fit-content;
	background: white;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
	border-radius: 5px;
}
.tabel-pendaftar table {
	border-collapse: collapse;
	border: none;
	width: 100%;
	color: rgba(0, 0, 0, 0.6);
	font-size: 0.9em;
}
.tabel-pendaftar table tr th {
	padding: 10px;
	text-align: left;
}
.tabel-pendaftar table tr td {
	padding: 10px;
	text-transform: capitalize;
}
.tabel-pendaftar table tr:hover td {
	background: rgba(45,168,255,0.06);
	transition: 0.5s all;
}
.tabel-pendaftar table tr td p {
	width: fit-content; 
	padding: 2px 5px; 
	border-radius: 5px;
	margin: 0px;
}

.grafik {
	width: 40%;
	border-radius: 5px;
}

.grafik-pie,
.grafik-bar {
	padding: 20px;
	background: white;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
	border-radius: 5px;
	display: flex;
	flex-direction: column;
	align-items: center;
	margin-bottom: 20px;
}

@media only screen and (max-width: 990px) {
	.dash {
		padding: 0px 10px;
	}

	.profile {
		padding: 0px;
		padding-bottom: 10px;
	}
	.cards {
		grid-template-columns: repeat(2, 1fr);
		padding: 20px 0px;
	}

	.card {
		flex-direction: column;	
	}
	.card img {
		width: 30px;
	}
	.card h2 {
		font-size: 1.2em;
	}
	.text {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 0px 10px;
	}
	.text h3 {
		text-align: center;
	}

	.konten-tengah {
		flex-direction: column;
		padding: 0px;
	}

	.tabel-pendaftar {
		width: -webkit-fill-available;
	}

	.data-pendaftar {
		overflow-x: auto;
	}
	.data-pendaftar table {
		width: 300%;
	}

	.grafik {
		width: -webkit-fill-available;
	}
	.grafik-pie {
		width: -webkit-fill-available;
	}
	.grafik-bar {
		width: -webkit-fill-available;
	}
}

	</style>
</head>

<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="data-pendaftar.php">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Data Pendaftar</p>
			</a>

			<a href="verifikasi-berkas.php">
				<img src="../asset/icon/berkas.png">
				<p id="hide">Verifikasi Berkas</p>
			</a>

			<a href="pengumuman-seleksi.php">
				<img src="../asset/icon/pengumuman.png">
				<p id="hide">Pengumuman Seleksi</p>
			</a>

			<a href="laporan.php">
				<img src="../asset/icon/laporan.png">
				<p id="hide">Laporan</p>
			</a>

			<a href="manajemen-admin.php">
				<img src="../asset/icon/admin.png">
				<p id="hide">Manajemen Admin</p>
			</a>	

			<a href="pengaturan-ppdb.php">
				<img src="../asset/icon/setting_ppdb.png">
				<p id="hide">Pengaturan PPDB</p>
			</a>

			<a href="halaman-depan.php">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Dashboard</p>
		</div>

		<div class="cards">
			<a href="guru.php" style="text-decoration: none;">
				<div class="card">
					<img src="../asset/icon/daftar2.png">
					<div class="text">
						<h3>Pendaftar</h3>
						<h2><?= $jumlah_ppdb ?></h2>
					</div>
				</div>
			</a>

			<a href="absensi-guru.php" style="text-decoration: none;">
				<div class="card">
					<img src="../asset/icon/unverif2.png">
					<div class="text">
						<h3>Menunggu Validasi</h3>
						<h2><?= $jumlah_menunggu ?></h2>
					</div>
				</div>
			</a>

			<a href="absensi-siswa.php" style="text-decoration: none;">
				<div class="card">
					<img src="../asset/icon/tolak2.png">
					<div class="text">
						<h3>Pendaftar Ditolak</h3>
						<h2><?= $jumlah_ditolak ?></h2>
					</div>
				</div>
			</a>

			<a href="izin-sakit.php" style="text-decoration: none;">
				<div class="card">
					<img src="../asset/icon/terima2.png">
					<div class="text">
						<h3>Pendaftar Diterima</h3>
						<h2><?= $jumlah_diterima ?></h2>
					</div>
				</div>
			</a>
		</div>

		<div class="konten-tengah">
			<div class="tabel-pendaftar">
				<h4>Pendaftar Terbaru</h4>
				<div class="data-pendaftar">
					<table>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Jenjang</th>
							<th>Kelengkapan Data</th>
							<th>Status</th>
						</tr>

						<?php
							$no = 1;
							while ($data_pd = $result->fetch_assoc()) { 

								if ($data_pd['status_berkas'] == 'kurang lengkap') {
									$back = '#ff45001c';
									$clr = 'darkorange';
								} elseif ($data_pd['status_berkas'] == 'lengkap') {
									$back = '#0080001c';
									$clr = 'darkgreen';
								} else {
									$back = '#ff00001c';
									$clr = 'darkred';
								}

								if ($data_pd['status'] == 'diterima') {
									$back2 = '#0080001c';
									$clr2 = 'darkgreen';
								} elseif ($data_pd['status'] == 'menunggu validasi') {
									$back2 = '#ff45001c';
									$clr2 = 'darkorange';
								} else {
									$back2 = '#8B000038';
									$clr2 = 'darkred';
								}
						?>
								<tr>
									<td><?= $no++ ?></td>
									<td><?= $data_pd['nama_siswa'] ?></td>
									<td style="text-transform: uppercase;"><?= $data_pd['jenjang'] ?></td>
									<td>
										<p style="background-color: <?= $back ?>; color: <?= $clr ?>;"><?= $data_pd['status_berkas'] ?></p>
									</td>
									<td>
										<p style="background-color: <?= $back2 ?>; color: <?= $clr2 ?>;"><?= $data_pd['status'] ?></p>
									</td>
								</tr>
							<?php	}
						?>
					</table>
				</div>
			</div>

			<div class="grafik">
				<div class="grafik-pie">
					<h4>Status Validasi</h4>
					<canvas id="statusChart" width="400" height="200"></canvas>
				</div>
				<div class="grafik-bar">
					<h4>Jumlah Pendaftar Perjenjang</h4>
					<canvas id="jenjangChart" width="250" height="150"></canvas>
				</div>
			</div>
		</div>

	</div>

</body>

<script>
	const diterima = <?= $jumlah_diterima ?>;
	const menunggu = <?= $jumlah_menunggu ?>;
	const ditolak = <?= $jumlah_ditolak ?>;

	const ctx = document.getElementById('statusChart').getContext('2d');

	new Chart(ctx, {
	    type: 'pie',
	    data: {
	        labels: ['Diterima', 'Menunggu Validasi', 'Ditolak'],
	        datasets: [{
	            data: [diterima, menunggu, ditolak],
	            backgroundColor: ['#28a745', '#ffc107', '#ff0000'],
	            borderColor: '#fff',
	            borderWidth: 2
	        }]
	    },
	    options: {
	        responsive: false,          // <-- kunci utama
	        maintainAspectRatio: false, // <-- biar ukuran tetap sesuai canvas
	        plugins: {
	            legend: {
	                position: 'bottom'
	            }
	        }
	    }
	});


	// Data PHP ke JavaScript
	const jenjangLabels = <?= json_encode($labels) ?>;
	const jenjangValues = <?= json_encode($values) ?>;

	const ctx2 = document.getElementById('jenjangChart').getContext('2d');

	new Chart(ctx2, {
	    type: 'bar',
	    data: {
	        labels: jenjangLabels,
	        datasets: [{
	            label: 'Jumlah Pendaftar per Jenjang',
	            data: jenjangValues,
	            backgroundColor: ['#0d6efd', '#198754', '#ffc107'],
	            borderColor: '#fff',
	            borderWidth: 1
	        }]
	    },
	    options: {
	        responsive: false,          // <-- fix ukuran
	        maintainAspectRatio: false, // <-- supaya width/height terpenuhi
	        scales: {
	            y: {
	                beginAtZero: true,
	                ticks: { stepSize: 1 }
	            }
	        },
	        plugins: {
	            legend: {
	                position: 'bottom'
	            }
	        }
	    }
	});

</script>

<script>
const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>