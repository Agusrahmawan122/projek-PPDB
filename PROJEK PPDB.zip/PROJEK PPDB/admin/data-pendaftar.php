<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

$nama  = $_POST['nama'] ?? $_GET['nama'] ?? '';
$limit = $_GET['limit'] ?? 10;
$page  = $_GET['page'] ?? 1;

$page   = max(1, (int)$page);
$limit  = (int)$limit;
$offset = ($page - 1) * $limit;

// WHERE
$where  = "WHERE kp.status_ppdb = 'aktif'";
$params = [];
$types  = "";

if (!empty($nama)) {
    $where .= " AND dp.nama_siswa LIKE ?";
    $params[] = "%$nama%";
    $types .= "s";
}

// TOTAL DATA
$sqlCount = "SELECT COUNT(*) AS total FROM data_pendaftar dp
    LEFT JOIN pengguna p ON dp.id_pengguna = p.id_pengguna
    LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    LEFT JOIN data_ortu do ON dp.id_ortu = do.id_ortu
    $where";

$stmt = $koneksi->prepare($sqlCount);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalData = $stmt->get_result()->fetch_assoc()['total'];
$totalPage = ceil($totalData / $limit);

// DATA
$sql = "SELECT * FROM data_pendaftar dp
    LEFT JOIN pengguna p ON dp.id_pengguna = p.id_pengguna
    LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    LEFT JOIN data_ortu do ON dp.id_ortu = do.id_ortu
    $where
    ORDER BY dp.tanggal DESC
    LIMIT ?, ?";

$paramsData = $params;
$paramsData[] = $offset;
$paramsData[] = $limit;
$typesData = $types . "ii";

$stmt6 = $koneksi->prepare($sql);
$stmt6->bind_param($typesData, ...$paramsData);
$stmt6->execute();
$result6 = $stmt6->get_result();

$no = $offset + 1;

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style type="text/css">
body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: #f5f8fb;
}
.profile {
	display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: 0.9em;
    padding: 10px 0px;
    text-transform: capitalize;
    color: rgba(0,0,0,0.6);
}
.profile button {
	width: 50px;
	height: 50px;
	border: none;
	outline-style: none;
	border-radius: 50px;
	background-size: cover;
	margin: 0px 10px;
}
.nama p {
	margin: 0px;
	color: rgba(0,0,0,0.6);
}
.profile a {
	text-decoration: none;
	margin: 0px 10px;
}
.profile a img {
	width: 30px;
}
.profile a img:hover {
	background: rgba(255, 0, 0, 0.13);
    border-radius: 5px;
    transition: 0.5s all;

}

.navbar {
	position: fixed;
	top: 0px;
	bottom: 0px;
	width: 300px;
	transition: 0.5s all;
}
.menu {
	background: #2da8ff;
	color: white;
	border-radius: 25px;
	padding: 10px;
}

.logo img {
	width: 50px;
	margin: 10px 10px;
}
.logo p {
	font-weight: bold;
	color: rgba(0,0,0,0.6);
}

.menu h5 {
	font-size: 0.9em;
	font-weight: normal;
	padding: 10px;
	margin: 0px;
}
.menu a {
	display: flex;
	align-items: center;
	color: white;
	text-decoration: none;
	padding: 10px;
	font-size: 0.9em;
	margin: 5px 0px;
}
.menu a img {
	width: 20px;
}
.menu a p {
	margin: 0px 5px;
}

.dash {
	margin-left: 300px;
	padding: 0px 20px;
	transition: 0.5s all;
}

.btn-menu {
	display: flex;
	align-items: center;
}
.btn-menu button {
	width: 30px;
	height: 30px;
	outline-style: none;
	border: none;
	background: transparent;
}
.btn-menu p {
	margin: 0px 10px;
	font-size: 1.2em;
	color: #2da8ff;
	font-weight: bold;
}

.konten-tengah {
	padding: 20px;
}

.tabel-pendaftar {
	background: white;
	padding: 20px;
	font-size: 0.9em;
}
.tabel-pendaftar table {
	width: 100%;
	border-collapse: collapse;
	margin: 20px 0px;
}
.tabel-pendaftar table tr th {
	padding: 10px;
	font-size: 0.9em;
	color: #2da8ff;
	text-align: left;
}
.tabel-pendaftar table tr td {
	padding: 10px;
	font-size: 0.9em;
	color: rgba(0, 0, 0, 0.6);
	text-transform: capitalize;
}
.tabel-pendaftar table tr:hover td {
	background: rgba(45,168,255,0.06);
	transition: 0.5s all;
}

.detail-row {
	display: none;
	background: rgba(45,168,255,0.06);
}

.detail-wrapper {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    padding: 15px;
}

.detail-box {
    background: #fff;
    border-radius: 8px;
    padding: 12px;
    box-shadow: 0 0 5px rgba(0,0,0,.05);
}

.detail-box h4 {
    margin-bottom: 10px;
}

.detail-box table td {
    padding: 4px 6px;
}

#detail,
.btn-cetak {
	padding: 5px;
	display: flex;
	margin: 0px 5px;
	border: none;
	outline-style: none;
	background: transparent;
	border-radius: 5px;
	transition: 0.5s all;
}
#detail:hover {
	background: rgb(45 168 255 / 26%);
}
#detail img {
	width: 20px;
	height: 20px;
}

.btn-cetak:hover {
	background: #00640040;
}
.btn-cetak img {
	width: 20px;
	height: 20px;
}

.cari {
	padding: 10px 0px;
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.cari input {
	padding: 10px;
	width: 200px;
	border: 1px solid #2da8ff40;
	color: rgba(0, 0, 0, 0.6);
	font-size: 0.9em;
	outline-style: none;
	border-radius: 5px;
	box-shadow: 0px 0px 5px #2da8ff45;
	transition: 0.5s all;
}
.cari input:hover {
	background: rgba(45,168,255,0.06);
}
.cari button {
	padding: 10px;
	border: none;
	outline-style: none;
	font-size: 0.9em;
	font-weight: bold;
	width: 100px;
	margin: 0px 10px;
	border-radius: 5px;
	background: #2da8ff;
	color: white;
	transition: 0.5s all;
}
.cari button:hover {
	background: #0a58ca;
}

#down {
	display: flex;
	align-items: center;
	justify-content: space-around;
	padding: 8px;
	background: green;
	font-size: 0.9em;
	color: white;
	text-decoration: none;
	border-radius: 5px;
	width: 100px;
}
#down img {
	width: 20px;
	height: 20px;
}

.show-paging {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 10px 0px;
}

.paging a {
	text-decoration: none;
	padding: 8px;
	border-radius: 5px;
	margin-right: 5px;
	color: #2da8ff;
}
.active {
	background: rgba(45,168,255,0.06);
	border: 1px solid #2da8ff40;
}

.show {
	color: rgba(0, 0, 0, 0.6);
}
.show select {
	padding: 8px;
	border: 1px solid #2da8ff40;
	color: rgba(0, 0, 0, 0.6);
	border-radius: 5px;
	outline-style: none;
}

@media only screen and (max-width: 990px) {
	.dash {
		padding: 0px 10px;
	}

	.profile {
		padding: 0px;
		padding-bottom: 10px;
	}
}

	</style>
</head>

<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="data-pendaftar.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Data Pendaftar</p>
			</a>

			<a href="verifikasi-berkas.php">
				<img src="../asset/icon/berkas.png">
				<p id="hide">Verifikasi Berkas</p>
			</a>

			<a href="pengumuman-seleksi.php">
				<img src="../asset/icon/pengumuman.png">
				<p id="hide">Pengumuman Seleksi</p>
			</a>

			<a href="laporan.php">
				<img src="../asset/icon/laporan.png">
				<p id="hide">Laporan</p>
			</a>

			<a href="manajemen-admin.php">
				<img src="../asset/icon/admin.png">
				<p id="hide">Manajemen Admin</p>
			</a>	

			<a href="pengaturan-ppdb.php">
				<img src="../asset/icon/setting_ppdb.png">
				<p id="hide">Pengaturan PPDB</p>
			</a>

			<a href="halaman-depan.php">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Data Pendaftar</p>
		</div>

		<div class="konten-tengah">
			<div class="tabel-pendaftar">
				<div class="cari">
					<form action="" method="POST">
					    <input type="text" name="nama" value="<?= htmlspecialchars($nama) ?>" placeholder="Masukan Nama ...">
					    <button name="cari">Cari</button>
					</form>

					<a id="down" href="download-data-pendaftar.php">
						<img src="../asset/icon/download.png">
						Download
					</a>
				</div>
				<table>
					<tr>
						<th style="width: 30px;">No</th>
						<th>No. Pendaftaran</th>
						<th>Nama Siswa</th>
						<th>Asal Sekolah</th>
						<th>Jenjang</th>
						<th>Berkas</th>
						<th>Tanggal Daftar</th>
						<th style="text-align: center;">Aksi</th>
					</tr>
					<?php while ($data_ppdb = $result6->fetch_assoc()) { 

						if ($data_ppdb['status_berkas'] == 'kurang lengkap') {
							$back = '#ff45001c';
							$clr = 'darkorange';
						} elseif ($data_ppdb['status_berkas'] == 'lengkap') {
							$back = '#0080001c';
							$clr = 'darkgreen';
						} else {
							$back = '#ff00001c';
							$clr = 'darkred';
						}

						?>
						<tr>
							<td><?= $no++ ?></td>
							<td><?= $data_ppdb['no_daftar'] ?></td>
							<td><?= $data_ppdb['nama_siswa'] ?></td>
							<td><?= $data_ppdb['asal_sekolah'] ?></td>
							<td><?= $data_ppdb['jenjang'] ?></td>
							<td>
								<p style="padding: 5px; border-radius: 5px; margin: 0px; width: fit-content; background: <?= $back ?>; color: <?= $clr ?>;"><?= $data_ppdb['status_berkas'] ?></p>
							</td>
							<td><?= $data_ppdb['tanggal'] ?></td>
							<td style="display: flex; align-items: center; justify-content: center;">
								<button id="detail" class="data-row">
									<img src="../asset/icon/eye.png">
								</button>
								<a href="cetak_ppdb.php?id=<?= $data_ppdb['id_pendaftar'] ?>" 
							       target="_blank"
							       class="btn-cetak">
							       <img src="../asset/icon/print.png">
							    </a>
							</td>
						</tr>
						<tr class="detail-row">
					        <td colspan="8">
					            <div class="detail-wrapper">

					                <div class="detail-box">
					                    <h4>👦 Data Siswa</h4>
					                    <table>
					                        <tr><td>Nama</td><td>: <?= $data_ppdb['nama_siswa'] ?></td></tr>
					                        <tr><td>NISN</td><td>: <?= $data_ppdb['nisn'] ?></td></tr>
					                        <tr><td>Asal Sekolah</td><td>: <?= $data_ppdb['asal_sekolah'] ?></td></tr>
					                        <tr><td>Jenis Kelamin</td><td>: <?= $data_ppdb['gender'] ?></td></tr>
					                        <tr><td>Tempat, Tanggal Lahir</td><td>: <?= $data_ppdb['ttl'] ?></td></tr>
					                        <tr><td>Agama</td><td>: <?= $data_ppdb['agama'] ?></td></tr>
					                        <tr><td>Alamat</td><td>: <?= $data_ppdb['alamat'] ?></td></tr>
					                        <tr><td>No. HP</td><td>: <?= $data_ppdb['no_hp'] ?></td></tr>
					                        <tr><td>E-Mail</td><td>: <?= $data_ppdb['email'] ?></td></tr>
					                    </table>
					                </div>

					                <div class="detail-box">
					                    <h4>👨‍👩‍👧 Data Orang Tua</h4>
					                    <table>
					                        <tr><td>Nama Ayah</td><td>: <?= $data_ppdb['nama_ayah'] ?></td></tr>
					                        <tr><td>Tempat, Tanggal Lahir</td><td>: <?= $data_ppdb['ttl_ayah'] ?></td></tr>
					                        <tr><td>Pendidikan Terakhir</td><td>: <?= $data_ppdb['pendidikan_ayah'] ?></td></tr>
					                        <tr><td>Pekerjaan</td><td>: <?= $data_ppdb['pekerjaan_ayah'] ?></td></tr>
					                        <tr><td>No. HP</td><td>: <?= $data_ppdb['no_hp_ayah'] ?></td></tr>
					                        <tr><td>Nama Ibu</td><td>: <?= $data_ppdb['nama_ibu'] ?></td></tr>
					                        <tr><td>Tempat, Tanggal Lahir</td><td>: <?= $data_ppdb['ttl_ibu'] ?></td></tr>
					                        <tr><td>Pendidikan Terakhir</td><td>: <?= $data_ppdb['pendidikan_ibu'] ?></td></tr>
					                        <tr><td>Pekerjaan</td><td>: <?= $data_ppdb['pekerjaan_ibu'] ?></td></tr>
					                        <tr><td>No. HP</td><td>: <?= $data_ppdb['no_hp_ibu'] ?></td></tr>
					                    </table>
					                </div>

					            </div>
					        </td>
					    </tr>
					<?php	}	?>
				</table>
				<div class="show-paging">
					<div class="paging">
						<?php
							$start = max(1, $page - 1);
							$end   = min($totalPage, $page + 1);

							// PREV
							if ($page > 1) {
							    echo "<a href='?page=".($page-1)."&limit=$limit&nama=$nama'>Prev</a>";
							}

							// ANGKA (maks 2 angka → total 4 tombol)
							for ($i = $start; $i <= $end; $i++) {
							    $active = ($i == $page) ? "class='active'" : "";
							    echo "<a $active href='?page=$i&limit=$limit&nama=$nama'>$i</a>";
							}

							// NEXT
							if ($page < $totalPage) {
							    echo "<a href='?page=".($page+1)."&limit=$limit&nama=$nama'>Next</a>";
							}
							?>

					</div>

					<div class="show">
					    show
					    <form method="GET" style="display:inline;">
					        <select name="limit" onchange="this.form.submit()">
					            <option value="10" <?= $limit==10?'selected':'' ?>>10</option>
					            <option value="25" <?= $limit==25?'selected':'' ?>>25</option>
					            <option value="50" <?= $limit==50?'selected':'' ?>>50</option>
					            <option value="75" <?= $limit==75?'selected':'' ?>>75</option>
					            <option value="100" <?= $limit==100?'selected':'' ?>>100</option>
					        </select>
					        <input type="hidden" name="nama" value="<?= $nama ?>">
					    </form>
					    entries
					</div>

				</div>
			</div>
		</div>

	</div>

</body>

<script>
document.querySelectorAll(".data-row").forEach((row) => {
  row.addEventListener("click", (e) => {
    e.preventDefault(); // agar tidak reload halaman bila <a> punya href
    const tr = row.closest("tr"); // cari tr induk
    const detailRow = tr.nextElementSibling; // ambil baris setelahnya
    if (detailRow && detailRow.classList.contains("detail-row")) {
      detailRow.style.display =
        detailRow.style.display === "table-row" ? "none" : "table-row";
    }
  });
});

const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>