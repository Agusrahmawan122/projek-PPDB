<?php
include '../asset/config/koneksi.php';

$id = $_GET['id'] ?? 0;

$stmt = $koneksi->prepare("SELECT * FROM berkas WHERE id_berkas = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    die("Data berkas tidak ditemukan");
}

$zip = new ZipArchive();
$filename = "berkas_ppdb_{$id}.zip";

$tmpFile = tempnam(sys_get_temp_dir(), 'zip');
$zip->open($tmpFile, ZipArchive::CREATE);

// lokasi folder berkas (SESUAIKAN)
$folder = "../asset/img/";

$files = [
    'kk'        => 'KK',
    'akta'      => 'Akta',
    'ijazah'    => 'Ijazah',
    'ktp_ayah'  => 'KTP_Ayah',
    'ktp_ibu'   => 'KTP_Ibu'
];

foreach ($files as $field => $name) {
    if (!empty($data[$field]) && file_exists($folder.$data[$field])) {
        $zip->addFile($folder.$data[$field], $name."_".$data[$field]);
    }
}

$zip->close();

header("Content-Type: application/zip");
header("Content-Disposition: attachment; filename=$filename");
header("Content-Length: " . filesize($tmpFile));

readfile($tmpFile);
unlink($tmpFile);
exit;
