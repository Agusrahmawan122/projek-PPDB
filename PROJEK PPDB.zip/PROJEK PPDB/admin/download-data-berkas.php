<?php
include '../asset/config/koneksi.php';

header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=data-berkas-ppdb.xls");
echo "\xEF\xBB\xBF";

if (!function_exists('cek')) {
    function cek($data) {
        return !empty($data) ? 'ADA' : 'TIDAK';
    }
}

$sql = "SELECT dp.no_daftar, dp.nama_siswa,
        b.kk, b.akta, b.ijazah, b.ktp_ayah, b.ktp_ibu,
        b.status_berkas, b.catatan
    FROM data_pendaftar dp
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas";

$result = mysqli_query($koneksi, $sql);
?>

<table border="1">
<tr>
    <th>No</th>
    <th>No. Pendaftaran</th>
    <th>Nama Siswa</th>
    <th>KK</th>
    <th>Akta</th>
    <th>Ijazah</th>
    <th>KTP Ayah</th>
    <th>KTP Ibu</th>
    <th>Status</th>
    <th>Catatan</th>
</tr>

<?php $no=1; while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $row['no_daftar'] ?></td>
    <td><?= $row['nama_siswa'] ?></td>
    <td><?= cek($row['kk']) ?></td>
    <td><?= cek($row['akta']) ?></td>
    <td><?= cek($row['ijazah']) ?></td>
    <td><?= cek($row['ktp_ayah']) ?></td>
    <td><?= cek($row['ktp_ibu']) ?></td>
    <td><?= $row['status_berkas'] ?></td>
    <td><?= $row['catatan'] ?></td>
</tr>
<?php } ?>
</table>
