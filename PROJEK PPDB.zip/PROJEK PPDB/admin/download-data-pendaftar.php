<?php
include '../asset/config/koneksi.php';

// Header supaya terbaca sebagai file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Pendaftar_PPDB.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Ambil data
$sql = "SELECT * FROM data_pendaftar dp
        LEFT JOIN pengguna p ON dp.id_pengguna = p.id_pengguna
        LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
        LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
        LEFT JOIN data_ortu do ON dp.id_ortu = do.id_ortu
        WHERE kp.status_ppdb = 'aktif'
        ORDER BY dp.tanggal DESC";

$query = $koneksi->query($sql);
?>

<table border="1">
    <tr style="background:#f0f0f0; font-weight:bold;">
        <th>No</th>
        <th>No Pendaftaran</th>
        <th>Nama Siswa</th>
        <th>NISN</th>
        <th>Asal Sekolah</th>
        <th>Jenjang</th>
        <th>Status Berkas</th>
        <th>Tanggal Daftar</th>
        <th>Jenis Kelamin</th>
        <th>TTL</th>
        <th>Agama</th>
        <th>Alamat</th>
        <th>No HP</th>
        <th>Email</th>
    </tr>

    <?php
    $no = 1;
    while ($row = $query->fetch_assoc()) {
    ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['no_daftar'] ?></td>
        <td><?= $row['nama_siswa'] ?></td>
        <td>'<?= $row['nisn'] ?></td>
        <td><?= $row['asal_sekolah'] ?></td>
        <td><?= $row['jenjang'] ?></td>
        <td><?= $row['status_berkas'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td><?= $row['gender'] ?></td>
        <td><?= $row['ttl'] ?></td>
        <td><?= $row['agama'] ?></td>
        <td><?= $row['alamat'] ?></td>
        <td>'<?= $row['no_hp'] ?></td>
        <td><?= $row['email'] ?></td>
    </tr>
    <?php } ?>
</table>
