<?php
include '../asset/config/koneksi.php';

// header excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Pengumuman_PPDB.xls");
header("Pragma: no-cache");
header("Expires: 0");

// query data
$stmt = $koneksi->prepare("
    SELECT 
        dp.no_daftar,
        dp.nama_siswa,
        kp.jenjang,
        b.status_berkas,
        dp.status
    FROM data_pendaftar dp
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
    ORDER BY 
        CASE 
            WHEN dp.status = 'diterima' THEN 1
            WHEN dp.status = 'menunggu validasi' THEN 2
            WHEN dp.status = 'ditolak' THEN 3
            ELSE 4
        END
");
$stmt->execute();
$result = $stmt->get_result();
?>

<table border="1">
    <tr style="background:#f0f0f0;font-weight:bold;">
        <th>No</th>
        <th>No Pendaftaran</th>
        <th>Nama Siswa</th>
        <th>Jenjang</th>
        <th>Status Berkas</th>
        <th>Status Penerimaan</th>
    </tr>

    <?php $no = 1; ?>
    <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['no_daftar'] ?></td>
        <td><?= $row['nama_siswa'] ?></td>
        <td><?= strtoupper($row['jenjang']) ?></td>
        <td><?= ucfirst($row['status_berkas']) ?></td>
        <td><?= ucfirst($row['status']) ?></td>
    </tr>
    <?php } ?>
</table>
