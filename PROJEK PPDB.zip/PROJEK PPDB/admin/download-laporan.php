<?php
// koneksi
include '../asset/config/koneksi.php';

// Header Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Rekapitulasi_PPDB.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Query laporan
$sql = "
SELECT 
    kp.jenjang,

    COUNT(dp.id_pendaftar) AS total_pendaftar,

    SUM(dp.status = 'menunggu validasi') AS menunggu,
    SUM(dp.status = 'diterima') AS diterima,
    SUM(dp.status = 'ditolak') AS ditolak,

    SUM(b.status_berkas = 'lengkap') AS berkas_lengkap,
    SUM(b.status_berkas = 'kurang lengkap') AS berkas_kurang

FROM data_pendaftar dp
LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas

WHERE kp.status_ppdb = 'aktif'
GROUP BY kp.jenjang
ORDER BY kp.jenjang ASC
";

$result = $koneksi->query($sql);

// Variabel total
$total_pendaftar = 0;
$total_menunggu  = 0;
$total_diterima  = 0;
$total_ditolak   = 0;
$total_lengkap   = 0;
$total_kurang    = 0;
?>

<table border="1" cellpadding="5">
    <thead>
        <tr style="background-color:#eaeaea; font-weight:bold;">
            <th>No</th>
            <th>Jenjang</th>
            <th>Total Pendaftar</th>
            <th>Menunggu Validasi</th>
            <th>Diterima</th>
            <th>Ditolak</th>
            <th>Berkas Lengkap</th>
            <th>Berkas Kurang Lengkap</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        while ($row = $result->fetch_assoc()) {

            // Hitung total
            $total_pendaftar += $row['total_pendaftar'];
            $total_menunggu  += $row['menunggu'];
            $total_diterima  += $row['diterima'];
            $total_ditolak   += $row['ditolak'];
            $total_lengkap   += $row['berkas_lengkap'];
            $total_kurang    += $row['berkas_kurang'];
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= strtoupper($row['jenjang']) ?></td>
            <td><?= $row['total_pendaftar'] ?></td>
            <td><?= $row['menunggu'] ?></td>
            <td><?= $row['diterima'] ?></td>
            <td><?= $row['ditolak'] ?></td>
            <td><?= $row['berkas_lengkap'] ?></td>
            <td><?= $row['berkas_kurang'] ?></td>
        </tr>
        <?php } ?>

        <!-- TOTAL -->
        <tr style="font-weight:bold; background-color:#f5f5f5;">
            <td colspan="2" align="center">TOTAL</td>
            <td><?= $total_pendaftar ?></td>
            <td><?= $total_menunggu ?></td>
            <td><?= $total_diterima ?></td>
            <td><?= $total_ditolak ?></td>
            <td><?= $total_lengkap ?></td>
            <td><?= $total_kurang ?></td>
        </tr>
    </tbody>
</table>
