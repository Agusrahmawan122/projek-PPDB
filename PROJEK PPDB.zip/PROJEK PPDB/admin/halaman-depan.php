<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
	<style type="text/css">
body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: #f5f8fb;
}
.profile {
	display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: 0.9em;
    padding: 10px 0px;
    text-transform: capitalize;
    color: rgba(0,0,0,0.6);
}
.profile button {
	width: 50px;
	height: 50px;
	border: none;
	outline-style: none;
	border-radius: 50px;
	background-size: cover;
	margin: 0px 10px;
}
.nama p {
	margin: 0px;
	color: rgba(0,0,0,0.6);
}
.profile a {
	text-decoration: none;
	margin: 0px 10px;
}
.profile a img {
	width: 30px;
}
.profile a img:hover {
	background: rgba(255, 0, 0, 0.13);
    border-radius: 5px;
    transition: 0.5s all;

}

.navbar {
	position: fixed;
	top: 0px;
	bottom: 0px;
	width: 300px;
	transition: 0.5s all;
}
.menu {
	background: #2da8ff;
	color: white;
	border-radius: 25px;
	padding: 10px;
}

.logo img {
	width: 50px;
	margin: 10px 10px;
}
.logo p {
	font-weight: bold;
	color: rgba(0,0,0,0.6);
}

.menu h5 {
	font-size: 0.9em;
	font-weight: normal;
	padding: 10px;
	margin: 0px;
}
.menu a {
	display: flex;
	align-items: center;
	color: white;
	text-decoration: none;
	padding: 10px;
	font-size: 0.9em;
	margin: 5px 0px;
}
.menu a img {
	width: 20px;
}
.menu a p {
	margin: 0px 5px;
}

.dash {
	margin-left: 300px;
	padding: 0px 20px;
	transition: 0.5s all;
}

.btn-menu {
	display: flex;
	align-items: center;
}
.btn-menu button {
	width: 30px;
	height: 30px;
	outline-style: none;
	border: none;
	background: transparent;
}
.btn-menu p {
	margin: 0px 10px;
	font-size: 1.2em;
	color: #2da8ff;
	font-weight: bold;
}

.konten-tengah {
	font-size: 0.9em;
	padding: 0px 20px;
	border-radius: 5px;
}

.set-profil {
	padding: 10px 20px;
	background: white;
	margin: 20px 0px;
	border-radius: 5px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
}

#editor,
#editor2,
#editor3,
#editor4 {
	color: rgba(0, 0, 0, 0.6);
	transition: 0.5s all;
}
#editor:hover,
#editor2:hover,
#editor3:hover,
#editor4:hover {
	background: rgba(45,168,255,0.06);
}

#simpan-profil,
#simpan-jadwal,
#simpan-persyaratan,
#simpan-biaya,
#simpan-kontak {
	padding: 10px;
	font-size: 0.9em;
	margin: 20px 0px;
	width: 150px;
	border: none;
	outline-style: none;
	font-weight: bold;
	border-radius: 5px;
	background: #2da8ff;
	color: white;
	cursor: pointer;
	transition: 0.5s all;
}
#simpan-profil:hover,
#simpan-jadwal:hover,
#simpan-persyaratan:hover,
#simpan-biaya:hover,
#simpan-kontak:hover {
	background: #0a58ca;
}

.set-informasi {
	padding: 10px 20px;
	background: white;
	margin: 20px 0px;
	border-radius: 5px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 50px;
}

.set-kontak {
	padding: 10px 20px;
	background: white;
	margin: 20px 0px;
	border-radius: 5px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
}

.isi-kontak form {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 20px;
}
.input {
	display: flex;
	flex-direction: column;
}
.input strong {
	padding: 10px 0px;
	font-weight: normal;
	font-size: 0.9em;
}
.input input,
.input textarea {
	padding: 10px;
	font-size: 0.9em;
	border: 1px solid #2da8ff40;
	box-shadow: 0px 0px 5px #2da8ff45;
	border-radius: 5px;
	outline-style: none;
	resize: none;
	color: rgba(0, 0, 0, 0.6);
}
.input textarea {
	font-size: 1.2em;
}
.input input:hover,
.input textarea:hover {
	background: rgba(45,168,255,0.06);
}

@media only screen and (max-width: 990px) {
	.dash {
		padding: 0px 10px;
	}

	.profile {
		padding: 0px;
		padding-bottom: 10px;
	}
}

	</style>
</head>

<?php
include '../asset/config/koneksi.php';

$query = mysqli_query($koneksi, "SELECT profil FROM halaman_utama LIMIT 1");
$data = mysqli_fetch_assoc($query);
$profil_awal = $data['profil'];

// Proses Update
if (isset($_POST['submit'])) {
    $konten = mysqli_real_escape_string($koneksi, $_POST['konten']);

    $update = mysqli_query($koneksi, "UPDATE halaman_utama SET profil='$konten'");

    if ($update) {
        echo "<script>alert('Profil berhasil diperbarui!'); window.location.href='halaman-depan.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate profil!');</script>";
    }
}

$query = mysqli_query($koneksi, "SELECT jadwal FROM halaman_utama LIMIT 1");
$data = mysqli_fetch_assoc($query);
$jadwal_awal = $data['jadwal'];

// Proses Update
if (isset($_POST['submit2'])) {
    $konten2 = mysqli_real_escape_string($koneksi, $_POST['konten2']);

    $update = mysqli_query($koneksi, "UPDATE halaman_utama SET jadwal='$konten2'");

    if ($update) {
        echo "<script>alert('Jadwal berhasil diperbarui!'); window.location.href='halaman-depan.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate jadwal!');</script>";
    }
}

$query = mysqli_query($koneksi, "SELECT syarat FROM halaman_utama LIMIT 1");
$data = mysqli_fetch_assoc($query);
$persyaratan_awal = $data['syarat'];

// Proses Update
if (isset($_POST['submit3'])) {
    $konten3 = mysqli_real_escape_string($koneksi, $_POST['konten3']);

    $update = mysqli_query($koneksi, "UPDATE halaman_utama SET syarat='$konten3'");

    if ($update) {
        echo "<script>alert('Persyaratan berhasil diperbarui!'); window.location.href='halaman-depan.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate syarat!');</script>";
    }
}

$query = mysqli_query($koneksi, "SELECT biaya FROM halaman_utama LIMIT 1");
$data = mysqli_fetch_assoc($query);
$biaya_awal = $data['biaya'];

// Proses Update
if (isset($_POST['submit4'])) {
    $konten4 = mysqli_real_escape_string($koneksi, $_POST['konten4']);

    $update = mysqli_query($koneksi, "UPDATE halaman_utama SET biaya='$konten4'");

    if ($update) {
        echo "<script>alert('Biaya berhasil diperbarui!'); window.location.href='halaman-depan.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate biaya!');</script>";
    }
}

$query = mysqli_query($koneksi, "SELECT * FROM halaman_utama LIMIT 1");
$data_halaman = mysqli_fetch_assoc($query);

if (isset($_POST['submit5'])) {

    $alamat   = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $telepon  = mysqli_real_escape_string($koneksi, $_POST['telepon']);
    $wa       = mysqli_real_escape_string($koneksi, $_POST['wa']);
    $email    = mysqli_real_escape_string($koneksi, $_POST['email']);
    $jam      = mysqli_real_escape_string($koneksi, $_POST['jam']);
    $fb       = mysqli_real_escape_string($koneksi, $_POST['fb']);
    $ig       = mysqli_real_escape_string($koneksi, $_POST['ig']);
    $yt       = mysqli_real_escape_string($koneksi, $_POST['yt']);
    $tk       = mysqli_real_escape_string($koneksi, $_POST['tk']);

    $update = mysqli_query($koneksi, "
        UPDATE halaman_utama SET 
            alamat     = '$alamat',
            telepon    = '$telepon',
            wa         = '$wa',
            email      = '$email',
            jam        = '$jam',
            link_fb    = '$fb',
            link_ig    = '$ig',
            link_yt    = '$yt',
            link_tk    = '$tk'
    ");

    if ($update) {
        echo "<script>alert('Kontak berhasil diperbarui!'); window.location.href='".$_SERVER['PHP_SELF']."';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate kontak!');</script>";
    }
}

?>


<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="pengguna.php">
				<img src="../asset/icon/admin.png">
				<p id="hide">Pengguna</p>
			</a>

			<a href="pendaftar.php">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Pendaftar</p>
			</a>

			<a href="halaman-depan.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Halaman Depan</p>
		</div>

		<div class="konten-tengah">

			<div class="set-profil">
				<h4>Profil</h4>
				<div class="isi-profil">
				    <form id="form-profil" method="POST">

				        <div id="editor" style="height: 150px;">
				        </div>

				        <input type="hidden" name="konten" id="konten">

				        <button id="simpan-profil"type="submit" name="submit">Simpan</button>
				    </form>

				</div>
			</div>

			<div class="set-informasi">
				<div class="set-jadwal">
					<h4>Jadwal</h4>
					<div class="isi-jadwal">
						<form id="form-jadwal" method="POST">

					        <div id="editor2" style="height: 200px;">
					        </div>

					        <input type="hidden" name="konten2" id="konten2">

					        <button id="simpan-jadwal"type="submit" name="submit2">Simpan</button>
					    </form>
					</div>
				</div>

				<div class="set-persyaratan">
					<h4>Persyaratan</h4>
					<div class="isi-persyaratan">
						<form id="form-persyaratan" method="POST">

					        <div id="editor3" style="height: 200px;">
					        </div>

					        <input type="hidden" name="konten3" id="konten3">

					        <button id="simpan-persyaratan"type="submit" name="submit3">Simpan</button>
					    </form>
					</div>
				</div>

				<div class="set-biaya">
					<h4>Biaya</h4>
					<div class="isi-biaya">
						<form id="form-biaya" method="POST">

					        <div id="editor4" style="height: 200px;">
					        </div>

					        <input type="hidden" name="konten4" id="konten4">

					        <button id="simpan-biaya"type="submit" name="submit4">Simpan</button>
					    </form>
					</div>
				</div>
			</div>

			<div class="set-kontak">
				<h4>Kontak & Sosial Media</h4>
				<div class="isi-kontak">
					<form method="POST">
						<div class="input">
							<strong>Alamat</strong>
							<textarea name="alamat" rows="3"><?= $data_halaman['alamat'] ?></textarea>
						</div>
						<div class="input">
							<strong>Telepon</strong>
							<input type="text" name="telepon" maxlength="15" value="<?= $data_halaman['telepon'] ?>">
						</div>
						<div class="input">
							<strong>WhatsApp (WA)</strong>
							<input type="text" name="wa" maxlength="15" value="<?= $data_halaman['wa'] ?>">
						</div>
						<div class="input">
							<strong>E-Mail</strong>
							<input type="email" name="email" value="<?= $data_halaman['email'] ?>">
						</div>
						<div class="input">
							<strong>Jam Operasional</strong>
							<input type="text" name="jam" value="<?= $data_halaman['jam'] ?>">
						</div>
						<div class="input">
							<strong>Facebook</strong>
							<input type="text" name="fb" value="<?= $data_halaman['link_fb'] ?>">
						</div>
						<div class="input">
							<strong>Instagram</strong>
							<input type="text" name="ig" value="<?= $data_halaman['link_ig'] ?>">
						</div>
						<div class="input">
							<strong>Youtube</strong>
							<input type="text" name="yt" value="<?= $data_halaman['link_yt'] ?>">
						</div>
						<div class="input">
							<strong>TikTok</strong>
							<input type="text" name="tk" value="<?= $data_halaman['link_tk'] ?>">
						</div>
						<button id="simpan-kontak"type="submit" name="submit5">Simpan</button>
					</form>
				</div>
			</div>

		</div>

	</div>

</body>

<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

<script>
// Inisialisasi Quill
var quill = new Quill('#editor', {
    theme: 'snow'
});

// Mengisi editor dengan data dari database (PHP → JS)
var awal = <?php echo json_encode($profil_awal); ?>;
quill.root.innerHTML = awal;

// Event submit → masukkan HTML ke hidden input
document.getElementById('form-profil').addEventListener('submit', function() {
    let html = quill.root.innerHTML;
    document.getElementById('konten').value = html;
});

// Inisialisasi Quill
var quill2 = new Quill('#editor2', {
    theme: 'snow'
});

// Mengisi editor dengan data dari database (PHP → JS)
var awal2 = <?php echo json_encode($jadwal_awal); ?>;
quill2.root.innerHTML = awal2;

// Event submit → masukkan HTML ke hidden input
document.getElementById('form-jadwal').addEventListener('submit', function() {
    let html = quill2.root.innerHTML;
    document.getElementById('konten2').value = html;
});

// Inisialisasi Quill
var quill3 = new Quill('#editor3', {
    theme: 'snow'
});

// Mengisi editor dengan data dari database (PHP → JS)
var awal3 = <?php echo json_encode($persyaratan_awal); ?>;
quill3.root.innerHTML = awal3;

// Event submit → masukkan HTML ke hidden input
document.getElementById('form-persyaratan').addEventListener('submit', function() {
    let html = quill3.root.innerHTML;
    document.getElementById('konten3').value = html;
});

// Inisialisasi Quill
var quill4 = new Quill('#editor4', {
    theme: 'snow'
});

// Mengisi editor dengan data dari database (PHP → JS)
var awal4 = <?php echo json_encode($biaya_awal); ?>;
quill4.root.innerHTML = awal4;

// Event submit → masukkan HTML ke hidden input
document.getElementById('form-biaya').addEventListener('submit', function() {
    let html = quill4.root.innerHTML;
    document.getElementById('konten4').value = html;
});
</script>

<script>
const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>