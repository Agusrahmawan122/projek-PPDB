<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

$sql = "
SELECT 
    kp.jenjang,

    COUNT(dp.id_pendaftar) AS total_pendaftar,

    SUM(dp.status = 'menunggu validasi') AS menunggu,
    SUM(dp.status = 'diterima') AS diterima,
    SUM(dp.status = 'ditolak') AS ditolak,

    SUM(b.status_berkas = 'lengkap') AS berkas_lengkap,
    SUM(b.status_berkas = 'kurang lengkap') AS berkas_kurang

FROM data_pendaftar dp
LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas

WHERE kp.status_ppdb = 'aktif'
GROUP BY kp.jenjang
ORDER BY kp.jenjang ASC
";

$result = $koneksi->query($sql);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style type="text/css">
body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: #f5f8fb;
}
.profile {
	display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: 0.9em;
    padding: 10px 0px;
    text-transform: capitalize;
    color: rgba(0,0,0,0.6);
}
.profile button {
	width: 50px;
	height: 50px;
	border: none;
	outline-style: none;
	border-radius: 50px;
	background-size: cover;
	margin: 0px 10px;
}
.nama p {
	margin: 0px;
	color: rgba(0,0,0,0.6);
}
.profile a {
	text-decoration: none;
	margin: 0px 10px;
}
.profile a img {
	width: 30px;
}
.profile a img:hover {
	background: rgba(255, 0, 0, 0.13);
    border-radius: 5px;
    transition: 0.5s all;

}

.navbar {
	position: fixed;
	top: 0px;
	bottom: 0px;
	width: 300px;
	transition: 0.5s all;
}
.menu {
	background: #2da8ff;
	color: white;
	border-radius: 25px;
	padding: 10px;
}

.logo img {
	width: 50px;
	margin: 10px 10px;
}
.logo p {
	font-weight: bold;
	color: rgba(0,0,0,0.6);
}

.menu h5 {
	font-size: 0.9em;
	font-weight: normal;
	padding: 10px;
	margin: 0px;
}
.menu a {
	display: flex;
	align-items: center;
	color: white;
	text-decoration: none;
	padding: 10px;
	font-size: 0.9em;
	margin: 5px 0px;
}
.menu a img {
	width: 20px;
}
.menu a p {
	margin: 0px 5px;
}

.dash {
	margin-left: 300px;
	padding: 0px 20px;
	transition: 0.5s all;
}

.btn-menu {
	display: flex;
	align-items: center;
}
.btn-menu button {
	width: 30px;
	height: 30px;
	outline-style: none;
	border: none;
	background: transparent;
}
.btn-menu p {
	margin: 0px 10px;
	font-size: 1.2em;
	color: #2da8ff;
	font-weight: bold;
}

.konten-tengah {
	padding: 20px;
}

.tabel-pendaftar {
	background: white;
	padding: 20px;
	font-size: 0.9em;
	border-radius: 5px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
}
.tabel-pendaftar table {
	width: 100%;
	border-collapse: collapse;
	margin: 20px 0px;
}
.tabel-pendaftar table tr th {
	padding: 10px;
	font-size: 0.9em;
	color: #2da8ff;
	text-align: left;
}
.tabel-pendaftar table tr td {
	padding: 10px;
	font-size: 0.9em;
	color: rgba(0, 0, 0, 0.6);
	text-transform: capitalize;
}
.tabel-pendaftar table tr:hover td {
	background: rgba(45,168,255,0.06);
	transition: 0.5s all;
}

.cari button {
	padding: 10px;
	border: none;
	outline-style: none;
	font-size: 0.9em;
	font-weight: bold;
	width: 100px;
	margin: 0px 10px;
	border-radius: 5px;
	background: #2da8ff;
	color: white;
	transition: 0.5s all;
}
.cari button:hover {
	background: #0a58ca;
}

#down {
	display: flex;
	align-items: center;
	justify-content: space-around;
	padding: 8px;
	background: green;
	font-size: 0.9em;
	color: white;
	text-decoration: none;
	border-radius: 5px;
	width: 100px;
}
#down img {
	width: 20px;
	height: 20px;
}


@media only screen and (max-width: 990px) {
	.dash {
		padding: 0px 10px;
	}

	.profile {
		padding: 0px;
		padding-bottom: 10px;
	}
}

	</style>
</head>

<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="data-pendaftar.php">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Data Pendaftar</p>
			</a>

			<a href="verifikasi-berkas.php">
				<img src="../asset/icon/berkas.png">
				<p id="hide">Verifikasi Berkas</p>
			</a>

			<a href="pengumuman-seleksi.php">
				<img src="../asset/icon/pengumuman.png">
				<p id="hide">Pengumuman Seleksi</p>
			</a>

			<a href="laporan.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/laporan.png">
				<p id="hide">Laporan</p>
			</a>

			<a href="manajemen-admin.php">
				<img src="../asset/icon/admin.png">
				<p id="hide">Manajemen Admin</p>
			</a>	

			<a href="pengaturan-ppdb.php">
				<img src="../asset/icon/setting_ppdb.png">
				<p id="hide">Pengaturan PPDB</p>
			</a>

			<a href="halaman-depan.php">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Laporan</p>
		</div>

		<div class="konten-tengah">
			<div class="tabel-pendaftar">
				<div style="font-size: 0.9em; border-bottom: 1px solid lightgrey; margin-bottom: 10px;">
					<h4 style="font-size: 1.1em; margin: 10px 0px;">Laporan Rekapitulasi PPDB</h4>
					<p style="color: rgba(0, 0, 0, 0.6);">Rekap data pendaftaran dan hasil seleksi calon peserta didik baru
				        pada jenjang PPDB yang masih aktif.</p>
				</div>

				<div class="cari">
					<a id="down" href="download-laporan.php">
						<img src="../asset/icon/download.png">
						Download
					</a>
				</div>
				
				<table>
				    <tr>
				        <th>No</th>
				        <th>Jenjang</th>
				        <th>Total Pendaftar</th>
				        <th>Menunggu Validasi</th>
				        <th>Diterima</th>
				        <th>Ditolak</th>
				        <th>Berkas Lengkap</th>
				        <th>Berkas Kurang Lengkap</th>
				    </tr>

				    <?php 
				    $no = 1;
				    while ($row = $result->fetch_assoc()) { ?>
				    <tr>
				        <td><?= $no++ ?></td>
				        <td style="text-transform: uppercase;"><?= $row['jenjang'] ?></td>
				        <td><?= $row['total_pendaftar'] ?></td>
				        <td><?= $row['menunggu'] ?></td>
				        <td><?= $row['diterima'] ?></td>
				        <td><?= $row['ditolak'] ?></td>
				        <td><?= $row['berkas_lengkap'] ?></td>
				        <td><?= $row['berkas_kurang'] ?></td>
				    </tr>
				    <?php } ?>
				</table>

			</div>
		</div>

	</div>

</body>

<script>

const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>