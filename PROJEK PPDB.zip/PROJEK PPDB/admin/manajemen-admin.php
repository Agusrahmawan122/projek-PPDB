<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

$editMode = false;
$dataEdit = [];

if (isset($_GET['edit'])) {
    $editMode = true;
    $id = (int) $_GET['edit'];

    $stmt = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $dataEdit = $stmt->get_result()->fetch_assoc();
}

if (isset($_POST['tambah'])) {
	$username  = stripcslashes(strtolower($_POST['username']));
	$password  = password_hash($_POST['password'], PASSWORD_DEFAULT);
	$nama = $_POST['nama'];
	$email = $_POST['email'] ?? '';
	$status = $_POST['status'];

	$namaFoto = $_FILES['foto']['name'];
	$tmpFoto = $_FILES['foto']['tmp_name'];
	$folder = "../asset/img/";

	$stmt2 = $koneksi->prepare("SELECT * FROM pengguna WHERE username = ?");
	$stmt2->bind_param("s", $username);
	$stmt2->execute();
	$result = $stmt2->get_result();
	$cek = $result->num_rows;

	if ($cek > 0) {
		echo "<script>alert('Username sudah digunakan!'); window.location.href='".$_SERVER['PHP_SELF']."';</script>";
        exit;
	} else {

		if (!empty($namaFoto)) {
			$foto = $namaFoto;
		} else {
			$foto = "foto.png";
		}

		$stmt3 = $koneksi->prepare("INSERT INTO pengguna (nama, username, password, role, email, foto) VALUES (?, ?, ?, ?, ?, ?)");
		$stmt3->bind_param("ssssss", $nama, $username, $password, $status, $email, $foto);
		$stmt3->execute();

		if (!empty($namaFoto)) {
			move_uploaded_file($tmpFoto, $folder . $foto);
		}

		echo "<script>alert('Berhasil menambahkan pengguna!'); window.location.href='".$_SERVER['PHP_SELF']."';</script>";
        exit;
	}
}

if (isset($_POST['update'])) {

    $id       = $_POST['id_pengguna'];
    $username = stripcslashes(strtolower($_POST['username']));
    $nama     = $_POST['nama'];
    $status   = $_POST['status'];
    $email    = $_POST['email'] ?? '';

    $namaFoto = $_FILES['foto']['name'];
    $tmpFoto  = $_FILES['foto']['tmp_name'];
    $folder   = "../asset/img/";

    // Ambil foto lama
    $stmt = $koneksi->prepare("SELECT foto FROM pengguna WHERE id_pengguna=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $fotoLama = $stmt->get_result()->fetch_assoc()['foto'];

    // Foto baru?
    if (!empty($namaFoto)) {
        $foto = $namaFoto;
        move_uploaded_file($tmpFoto, $folder . $foto);
    } else {
        $foto = $fotoLama;
    }

    // Password opsional
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "UPDATE pengguna SET 
                    nama=?, username=?, password=?, role=?, email=?, foto=? 
                WHERE id_pengguna=?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("ssssssi", $nama, $username, $password, $status, $email, $foto, $id);
    } else {
        $sql = "UPDATE pengguna SET 
                    nama=?, username=?, role=?, email=?, foto=? 
                WHERE id_pengguna=?";
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("sssssi", $nama, $username, $status, $email, $foto, $id);
    }

    $stmt->execute();

    echo "<script>alert('Data berhasil diupdate'); window.location='pengguna.php';</script>";
    exit;
}


// ================== PARAMETER ==================
$cari   = $_POST['cari'] ?? $_GET['cari'] ?? '';
$status = $_POST['status'] ?? $_GET['status'] ?? '';
$limit  = $_GET['limit'] ?? 5;
$page   = $_GET['page'] ?? 1;

$page   = max(1, (int)$page);
$limit  = (int)$limit;
$offset = ($page - 1) * $limit;

// ================== WHERE ==================
$where = [];
$params = [];
$types  = '';

if (!empty($cari)) {
    $where[] = "(nama LIKE ? OR username LIKE ?)";
    $params[] = "%$cari%";
    $params[] = "%$cari%";
    $types   .= "ss";
}

if (!empty($status)) {
    $where[] = "role = ?";
    $params[] = $status;
    $types   .= "s";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

// ================== TOTAL DATA ==================
$sqlCount = "SELECT COUNT(*) AS total FROM pengguna $whereSQL";
$stmt = $koneksi->prepare($sqlCount);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalData = $stmt->get_result()->fetch_assoc()['total'];
$totalPage = ceil($totalData / $limit);

// ================== DATA ==================
$sql = "SELECT * FROM pengguna 
        $whereSQL
        ORDER BY role = 'admin' DESC
        LIMIT ?, ?";

$stmt = $koneksi->prepare($sql);
// Tambahkan limit & offset ke params
$paramsData = $params;
$paramsData[] = $offset;
$paramsData[] = $limit;

$typesData = $types . "ii";

$stmt->bind_param($typesData, ...$paramsData);
$stmt->execute();
$result = $stmt->get_result();

$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<link rel="stylesheet" type="text/css" href="../asset/css2/pengguna.css">
</head>

<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="pengguna.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/admin.png">
				<p id="hide">Pengguna</p>
			</a>

			<a href="pendaftar.php">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Pendaftar</p>
			</a>

			<a href="halaman-depan.php">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Pengguna</p>
		</div>

		<div class="konten-tengah">
			<div class="tambah-pengguna">
			    <h4><?= $editMode ? 'Edit Pengguna' : 'Tambah Pengguna' ?></h4>

			    <div class="form">
			        <form method="POST" enctype="multipart/form-data">

			            <?php if ($editMode) { ?>
			                <input type="hidden" name="id_pengguna" value="<?= $dataEdit['id_pengguna'] ?>">
			            <?php } ?>

			            <div class="input">
			                <label>Username</label>
			                <input type="text" name="username"
			                    value="<?= $editMode ? $dataEdit['username'] : ($_POST['username'] ?? '') ?>"
			                    required>
			            </div>

			            <div class="input">
			                <label>Nama</label>
			                <input type="text" name="nama"
			                    value="<?= $editMode ? $dataEdit['nama'] : ($_POST['nama'] ?? '') ?>"
			                    required>
			            </div>

			            <div class="input">
			                <label>Status</label>
			                <select name="status" required>
			                    <option value="">-- Pilih Status --</option>
			                    <option value="admin" <?= ($editMode && $dataEdit['role']=='admin')?'selected':'' ?>>Admin</option>
			                    <option value="pendaftar" <?= ($editMode && $dataEdit['role']=='pendaftar')?'selected':'' ?>>Pendaftar</option>
			                </select>
			            </div>

			            <div class="input">
			                <label>Password <?= $editMode ? '(Kosongkan jika tidak diubah)' : '' ?></label>
			                <input type="password" name="password">
			            </div>

			            <div class="input">
			                <label>E-Mail</label>
			                <input type="email" name="email"
			                    value="<?= $editMode ? $dataEdit['email'] : ($_POST['email'] ?? '') ?>">
			            </div>

			            <div class="input">
			                <label>Foto</label>
			                <div style="display: flex; justify-content: space-between;">   
				                <?php if ($editMode) { ?>
				                	<button style="background-image: url('../asset/img/<?= $dataEdit['foto'] ?>'); background-size: cover; width: 50px; height: 50px; border-radius: 50px; margin: 0px;"></button>
				                	<input type="file" name="foto" style="width: 80%;"> 
				                <?php } else { ?>
			                		<input type="file" name="foto"> 
				                <?php } ?>
			                </div>
			            </div>

			            <div>
			            	<?php if ($editMode) { ?>
				                <button name="update">Update</button>
				                <a id="batal" href="pengguna.php">Batal</a>
				            <?php } else { ?>
				                <button name="tambah">Tambah</button>
				            <?php } ?>
			            </div>

			        </form>
			    </div>
			</div>

			<div class="tabel-pengguna">
				<div class="data-pengguna">
					<div class="form-cari">
						<form method="POST">
			                <input type="text" name="cari" placeholder="Masukan Nama..." value="<?= htmlspecialchars($cari) ?>">
			                <button>Cari</button>
			            </form>

			            <form method="POST">
			                <select name="status" onchange="this.form.submit()">
			                    <option value="">-- Status --</option>
			                    <option value="admin" <?= $status=='admin'?'selected':'' ?>>Admin</option>
			                    <option value="pendaftar" <?= $status=='pendaftar'?'selected':'' ?>>Pendaftar</option>
			                </select>
			            </form>
					</div>
					
					<table>
			            <tr>
			                <th>No</th>
			                <th>Nama</th>
			                <th>Username</th>
			                <th>Email</th>
			                <th>Status</th>
			                <th>Foto</th>
			                <th>Aksi</th>
			            </tr>

			            <?php
			            $no = $offset + 1;
			            while ($data = $result->fetch_assoc()) { ?>
			                <tr>
			                    <td><?= $no++ ?></td>
			                    <td><?= $data['nama'] ?></td>
			                    <td><?= $data['username'] ?></td>
			                    <td><?= $data['email'] ?></td>
			                    <td><?= $data['role'] ?></td>
			                    <td>
			                        <button id="btn-foto" style="background-image:url('../asset/img/<?= $data['foto'] ?>'); background-size: cover;"></button>
			                    </td>
			                    <td align="center">
			                        <a href="?edit=<?= $data['id_pengguna'] ?>">
									    <button>Edit</button>
									</a>
			                        <button>Hapus</button>
			                    </td>
			                </tr>
			            <?php } ?>

			            <?php if ($totalData == 0) { ?>
			                <tr>
			                    <td colspan="7" align="center">Data tidak ditemukan</td>
			                </tr>
			            <?php } ?>
			        </table>
					<div class="show-paging">
						<div class="paging">
				        <?php
					        $start = max(1, $page - 1);
					        $end   = min($totalPage, $page + 1);

					        if ($page > 1) {
					            echo "<a href='?page=".($page-1)."&limit=$limit&cari=$cari&status=$status'>Prev</a>";
					        }

					        for ($i = $start; $i <= $end; $i++) {
					            $active = ($i == $page) ? "class='active'" : "";
					            echo "<a $active href='?page=$i&limit=$limit&cari=$cari&status=$status'>$i</a>";
					        }

					        if ($page < $totalPage) {
					            echo "<a href='?page=".($page+1)."&limit=$limit&cari=$cari&status=$status'>Next</a>";
					        }
				        ?>
				        </div>

				        <div class="show">
							<form method="GET">
								Show 
				                <select name="limit" onchange="this.form.submit()">
				                    <option value="5" <?= $limit==5?'selected':'' ?>>5</option>
				                    <option value="10" <?= $limit==10?'selected':'' ?>>10</option>
				                    <option value="25" <?= $limit==25?'selected':'' ?>>25</option>
				                </select>
				                <input type="hidden" name="cari" value="<?= $cari ?>">
				                <input type="hidden" name="status" value="<?= $status ?>">

				                entries
				            </form>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

</body>

<script>
const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>