<?php

include '../asset/config/koneksi.php';
session_start();

if (!isset($_SESSION['id_pengguna']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$id_pengguna = $_SESSION['id_pengguna'];
$role = $_SESSION['role'];

$stmtdata = $koneksi->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
$stmtdata->bind_param("i", $id_pengguna);
$stmtdata->execute();
$resultdata = $stmtdata->get_result();
$data_profil = $resultdata->fetch_assoc();

$id_edit = $_GET['id'] ?? '';

$jenjang = $tahun = $jumlah = $status = '';

if ($id_edit) {
    $stmt = $koneksi->prepare("SELECT * FROM kouta_ppdb WHERE id_kouta = ?");
    $stmt->bind_param("i", $id_edit);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if ($data) {
        $jenjang = $data['jenjang'];
        $tahun   = $data['tahun'];
        $jumlah  = $data['jumlah'];
        $status  = $data['status_ppdb'];
    }
}

/* =========================
   PROSES TAMBAH
========================= */
if (isset($_POST['tambah'])) {
    $jenjang = $_POST['jenjang'];
    $tahun   = $_POST['tahun'];
    $jumlah  = $_POST['jumlah'];
    $status  = $_POST['status'];

    $stmt = $koneksi->prepare("
        INSERT INTO kouta_ppdb (jenjang, tahun, jumlah, status_ppdb)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->bind_param("ssis", $jenjang, $tahun, $jumlah, $status);
    $stmt->execute();

    header("Location: pengaturan-ppdb.php");
    exit;
}

/* =========================
   PROSES UPDATE
========================= */
if (isset($_POST['update'])) {
    $id      = $_POST['id_kouta'];
    $jenjang = $_POST['jenjang'];
    $tahun   = $_POST['tahun'];
    $jumlah  = $_POST['jumlah'];
    $status  = $_POST['status'];

    $stmt = $koneksi->prepare("
        UPDATE kouta_ppdb 
        SET jenjang=?, tahun=?, jumlah=?, status_ppdb=?
        WHERE id_kouta=?
    ");
    $stmt->bind_param("ssisi", $jenjang, $tahun, $jumlah, $status, $id);
    $stmt->execute();

    header("Location: pengaturan-ppdb.php");
    exit;
}

/* =========================
   PROSES HAPUS
========================= */
if (isset($_GET['hapus'])) {

    $id = (int) $_GET['hapus'];

    /* Cek apakah kuota sudah dipakai */
    $cek = $koneksi->prepare("
        SELECT COUNT(*) AS total 
        FROM data_pendaftar 
        WHERE id_kouta = ?
    ");
    $cek->bind_param("i", $id);
    $cek->execute();
    $total = $cek->get_result()->fetch_assoc()['total'];

    if ($total > 0) {
        echo "<script>
            alert('Kuota tidak bisa dihapus karena sudah ada pendaftar!');
            window.location.href='pengaturan-ppdb.php';
        </script>";
        exit;
    }

    /* Hapus data */
    $hapus = $koneksi->prepare("DELETE FROM kouta_ppdb WHERE id_kouta = ?");
    $hapus->bind_param("i", $id);
    $hapus->execute();

    echo "<script>
        alert('Kuota berhasil dihapus!');
        window.location.href='pengaturan-ppdb.php';
    </script>";
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB-SMP/SMK UTAMA</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style type="text/css">
body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: #f5f8fb;
}
.profile {
	display: flex;
    align-items: center;
    justify-content: flex-end;
    font-size: 0.9em;
    padding: 10px 0px;
    text-transform: capitalize;
    color: rgba(0,0,0,0.6);
}
.profile button {
	width: 50px;
	height: 50px;
	border: none;
	outline-style: none;
	border-radius: 50px;
	background-size: cover;
	margin: 0px 10px;
}
.nama p {
	margin: 0px;
	color: rgba(0,0,0,0.6);
}
.profile a {
	text-decoration: none;
	margin: 0px 10px;
}
.profile a img {
	width: 30px;
}
.profile a img:hover {
	background: rgba(255, 0, 0, 0.13);
    border-radius: 5px;
    transition: 0.5s all;

}

.navbar {
	position: fixed;
	top: 0px;
	bottom: 0px;
	width: 300px;
	transition: 0.5s all;
}
.menu {
	background: #2da8ff;
	color: white;
	border-radius: 25px;
	padding: 10px;
}

.logo img {
	width: 50px;
	margin: 10px 10px;
}
.logo p {
	font-weight: bold;
	color: rgba(0,0,0,0.6);
}

.menu h5 {
	font-size: 0.9em;
	font-weight: normal;
	padding: 10px;
	margin: 0px;
}
.menu a {
	display: flex;
	align-items: center;
	color: white;
	text-decoration: none;
	padding: 10px;
	font-size: 0.9em;
	margin: 5px 0px;
}
.menu a img {
	width: 20px;
}
.menu a p {
	margin: 0px 5px;
}

.dash {
	margin-left: 300px;
	padding: 0px 20px;
	transition: 0.5s all;
}

.btn-menu {
	display: flex;
	align-items: center;
}
.btn-menu button {
	width: 30px;
	height: 30px;
	outline-style: none;
	border: none;
	background: transparent;
}
.btn-menu p {
	margin: 0px 10px;
	font-size: 1.2em;
	color: #2da8ff;
	font-weight: bold;
}

.kotak {
	padding: 20px;
}

.kotak-tahun,
.data_kouta {
	background: white;
	padding: 10px 20px;
	border-radius: 5px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
	font-size: 0.9em;
}

.tambah-kouta form {
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	gap: 10px 50px;
}

.input {
	display: flex;
	flex-direction: column;
	color: rgba(0, 0, 0, 0.6);
	font-size: 0.9em;
}
.input input,
.input select {
    padding: 10px;
    font-size: 0.9em;
    border-radius: 5px;
    margin: 10px 0px;
    outline-style: none;
    border: 1px solid #2da8ff40;
    box-shadow: 0px 0px 5px #2da8ff45;
    color: rgba(0, 0, 0, 0.6);
    transition: 0.5s all;
    text-transform: capitalize;
}

.tambah-kouta button {
	width: 150px;
    font-weight: bold;
    border: none;
    padding: 10px;
    color: white;
    background: #2da8ff;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.5s all;
    margin-bottom: 20px;
}
.tambah-kouta button:hover {
	background: #0a58ca;
}

.data_kouta {
	margin: 20px 0px;
}

.tabel-kouta table {
	width: 100%;
	border-collapse: collapse;
	margin: 10px 0px;
}
.tabel-kouta table tr th {
	color: #2da8ff;
	font-size: 0.9em;
	padding: 10px;
	text-align: left;
}
.tabel-kouta table tr td {
	padding: 10px;
	color: rgba(0, 0, 0, 0.6);
	font-size: 0.9em;
}
.tabel-kouta table tr:hover td {
	background: rgba(45,168,255,0.06);
	transition: 0.5s all;
}

@media only screen and (max-width: 990px) {
	.dash {
		padding: 0px 10px;
	}

	.profile {
		padding: 0px;
		padding-bottom: 10px;
	}
}

	</style>
</head>

<body>

	<div class="profile">
		<button style="background-image: url('../asset/img/<?= $data_profil['foto']?>');"></button>
		<div class="nama">
			<strong><?= $data_profil['nama']?></strong>
			<p><?= $data_profil['role']?></p>
		</div>
		<a href="logout.php">
			<img src="../asset/icon/logout.png">
		</a>
	</div>

	<div class="navbar">
		<div class="logo" style="display: flex; align-items: center;">
			<img src="../asset/icon/logo.webp">
			<p id="hide">SMP-SMK UTAMA</p>
		</div>
		<div class="menu">
			<h5 id="hide">Dash Menu</h5>
			<a href="dashboard.php">
				<img src="../asset/icon/dash1.png">
				<p id="hide">Dashboard</p>
			</a>

			<a href="pengguna.php">
				<img src="../asset/icon/admin.png">
				<p id="hide">Pengguna</p>
			</a>

			<a href="pendaftar.php">
				<img src="../asset/icon/daftar3.png">
				<p id="hide">Pendaftar</p>
			</a>

			<a href="pengaturan-ppdb.php" style="background-color: #ffffff38; border-radius: 25px;">
				<img src="../asset/icon/setting_ppdb.png">
				<p id="hide">Pengaturan PPDB</p>
			</a>

			<a href="halaman-depan.php">
				<img src="../asset/icon/setting.png">
				<p id="hide">Halaman Depan</p>
			</a>
		</div>
	</div>

	<div class="dash">

		<div class="btn-menu">
			<button id="btn-menu" style="background-image: url('../asset/icon/menu2.png'); background-size: cover;"></button>
			<p>Pengaturan PPDB</p>
		</div>

		<div class="kotak">
			<div class="kotak-tahun">
		        <h4><?= $id_edit ? 'Edit Kouta PPDB' : 'Tambah Kouta PPDB' ?></h4>

		        <div class="tambah-kouta">
		            <form method="POST">

		                <?php if ($id_edit): ?>
		                    <input type="hidden" name="id_kouta" value="<?= $id_edit ?>">
		                <?php endif; ?>

		                <div class="input">
		                    <label>Jenjang/Jurusan</label>
		                    <input type="text" name="jenjang" value="<?= $jenjang ?>" required>
		                </div>

		                <div class="input">
		                    <label>Tahun Pelajaran</label>
		                    <input type="text" name="tahun" value="<?= $tahun ?>" required>
		                </div>

		                <div class="input">
		                    <label>Jumlah Kouta</label>
		                    <input type="number" name="jumlah" value="<?= $jumlah ?>" required>
		                </div>

		                <div class="input">
		                    <label>Status</label>
		                    <select name="status" required>
		                        <option value="">-- Pilih Status --</option>
		                        <option value="aktif" <?= $status=='aktif'?'selected':'' ?>>Aktif</option>
		                        <option value="tidak aktif" <?= $status=='tidak aktif'?'selected':'' ?>>Tidak Aktif</option>
		                    </select>
		                </div>

		                <div>
		                    <?php if ($id_edit): ?>
		                        <button name="update">Update</button>
		                        <a href="pengaturan-ppdb.php">Batal</a>
		                    <?php else: ?>
		                        <button name="tambah">Tambah</button>
		                    <?php endif; ?>
		                </div>

		            </form>
		        </div>
		    </div>

			<div class="data_kouta">
				<h4>Kouta PPDB</h4>
				<div class="tabel-kouta">
					<table>
						<tr>
							<th style="width:3%;">No</th>
							<th>Jenjang/Jurusan</th>
							<th>Tahun Pelajaran</th>
							<th>Kouta</th>
							<th>Sisa Kouta</th>
							<th>Status</th>
							<th style="width: 150px; text-align: center;">Aksi</th>
						</tr>
						<?php
							$stmt = $koneksi->prepare("
							    SELECT 
							        kp.id_kouta,
							        kp.jenjang,
							        kp.tahun,
							        kp.jumlah,
							        kp.status_ppdb,
							        COUNT(dp.id_kouta) AS total_daftar
							    FROM kouta_ppdb kp
							    LEFT JOIN data_pendaftar dp ON kp.id_kouta = dp.id_kouta
							    GROUP BY kp.id_kouta
							");
							$stmt->execute();
							$result = $stmt->get_result();
						?>
						<?php $no = 1; ?>
						<?php while ($data_kouta = $result->fetch_assoc()) { ?>
						<tr>
						    <td><?= $no++ ?></td>
						    <td style="text-transform: uppercase;"><?= $data_kouta['jenjang'] ?></td>
						    <td><?= $data_kouta['tahun'] ?></td>
						    <td><?= $data_kouta['jumlah'] ?></td>
						    <td>
						        <?= $data_kouta['jumlah'] - $data_kouta['total_daftar'] ?>
						    </td>
						    <td style="text-transform: capitalize;">
						        <?= $data_kouta['status_ppdb'] ?>
						    </td>
						    <td style="text-align: center;">
						        <a href="pengaturan-ppdb.php?id=<?= $data_kouta['id_kouta'] ?>">Edit</a>
						        <a href="?hapus=<?= $data_kouta['id_kouta'] ?>"
								   onclick="return confirm('Yakin hapus kuota ini?')">
								   Hapus
								</a>
						    </td>
						</tr>
						<?php } ?>
					</table>
				</div>
			</div>
		</div>

	</div>

</body>

<script>
const btnMenu = document.getElementById('btn-menu');
const navbar = document.querySelector('.navbar');
const cmenu = document.querySelector('.dash');
const logo = document.querySelector('.logo');
const hides = document.querySelectorAll('#hide');

function setNavbarState() {
	const state = localStorage.getItem('navbarState');
	const isMobile = window.matchMedia("(max-width: 480px)").matches;

	// ukuran default
	let minimizedWidth = isMobile ? 60 : 60;
	let expandedWidth = isMobile ? 200 : 300;

	let ML = isMobile ? 200 : 300;
	let ML2 = isMobile ? 60 : 60;
	
	if (state === 'minimized') {
		navbar.classList.add('minimized');
		hides.forEach(el => el.style.display = 'none');
		navbar.style.width = minimizedWidth + 'px';
		cmenu.style.marginLeft = ML2 + 'px';
		logo.style.textAlign = 'center';
	} else {
		navbar.classList.remove('minimized');
		hides.forEach(el => el.style.display = '');
		navbar.style.width = expandedWidth + 'px';
		cmenu.style.marginLeft = ML + 'px';
		logo.style.textAlign = 'left';
	}
}
setNavbarState();

btnMenu.addEventListener('click', () => {
	navbar.classList.toggle('minimized');
	localStorage.setItem('navbarState', navbar.classList.contains('minimized') ? 'minimized' : 'expanded');
	setNavbarState();
});
</script>

</html>