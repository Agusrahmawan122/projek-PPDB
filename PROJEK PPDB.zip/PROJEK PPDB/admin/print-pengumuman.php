<?php
include '../asset/config/koneksi.php';

$id = $_GET['id'] ?? '';

/* =======================
   DATA SEKOLAH
======================= */
$qProfil = $koneksi->query("SELECT * FROM halaman_utama LIMIT 1");
$profil = $qProfil->fetch_assoc();

/* =======================
   DATA PANITIA (ADMIN)
======================= */
$qPanitia = $koneksi->query("
    SELECT nama 
    FROM pengguna 
    WHERE role = 'admin' 
    ORDER BY id_pengguna ASC 
    LIMIT 1
");
$panitia = $qPanitia->fetch_assoc();

/* =======================
   DATA PENDAFTAR
======================= */
$stmt = $koneksi->prepare("
    SELECT 
        dp.*,
        kp.jenjang,
        b.status_berkas
    FROM data_pendaftar dp
    LEFT JOIN kouta_ppdb kp ON dp.id_kouta = kp.id_kouta
    LEFT JOIN berkas b ON dp.id_berkas = b.id_berkas
    WHERE dp.id_pendaftar = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    echo "<script>alert('Data tidak ditemukan');window.close();</script>";
    exit;
}

/* =======================
   STATUS PENGUMUMAN
======================= */
if ($data['status'] == 'diterima') {
    $judulStatus = "DITERIMA";
    $warna = "green";
} elseif ($data['status'] == 'ditolak') {
    $judulStatus = "DITOLAK";
    $warna = "red";
} else {
    $judulStatus = "MENUNGGU VALIDASI";
    $warna = "orange";
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Bukti Pengumuman PPDB</title>
<style>
body {
    font-family: "Times New Roman", serif;
    font-size: 14px;
}
.header {
    text-align: center;
}
.header h2 {
    margin: 0;
    font-size: 20px;
}
.header h3 {
    margin: 2px 0;
    font-size: 18px;
}
.header p {
    font-size: 12px;
    margin: 3px 0;
}
hr {
    border: 1px solid #000;
    margin: 10px 0 20px;
}
.judul {
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    text-decoration: underline;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
td {
    padding: 6px;
    vertical-align: top;
}
.status-box {
    text-align: center;
    font-size: 18px;
    font-weight: bold;
    margin: 20px 0;
    color: <?= $warna ?>;
}
.ttd {
    width: 100%;
    margin-top: 40px;
}
.ttd td {
    text-align: center;
}
@media print {
    button {
        display: none;
    }
}
</style>
</head>

<body onload="window.print()">

<!-- HEADER -->
<div class="header">
    <h2>YAYASAN PENDIDIKAN PUTRA GUMANTI (YPPG)</h2>
    <h3>SMP & SMK UTAMA</h3>
    <p><?= $profil['alamat'] ?></p>
    <p>
        Telp: <?= $profil['telepon'] ?> |
        WhatsApp: <?= $profil['wa'] ?> |
        Email: <?= $profil['email'] ?>
    </p>
</div>

<hr>

<div class="judul">PENGUMUMAN HASIL SELEKSI PPDB</div>

<!-- DATA SISWA -->
<table>
<tr>
    <td width="30%">No. Pendaftaran</td>
    <td>: <?= $data['no_daftar'] ?></td>
</tr>
<tr>
    <td>Nama Calon Siswa</td>
    <td>: <?= $data['nama_siswa'] ?></td>
</tr>
<tr>
    <td>Jenjang</td>
    <td>: <?= strtoupper($data['jenjang']) ?></td>
</tr>
<tr>
    <td>Tanggal Pendaftaran</td>
    <td>: <?= date('d-m-Y', strtotime($data['tanggal'])) ?></td>
</tr>
<tr>
    <td>Status Berkas</td>
    <td>: <?= ucfirst($data['status_berkas']) ?></td>
</tr>
</table>

<!-- STATUS -->
<div class="status-box">
    <?= $judulStatus ?>
</div>

<!-- KETERANGAN -->
<p style="text-align: justify;">
Berdasarkan hasil seleksi Penerimaan Peserta Didik Baru (PPDB) 
<strong>SMP & SMK UTAMA - Yayasan Pendidikan Putra Gumanti (YPPG)</strong>, 
maka calon peserta didik tersebut dinyatakan 
<strong><?= strtolower($judulStatus) ?></strong>.
</p>

<?php if ($data['status'] == 'diterima') { ?>
<p style="text-align: justify;">
Dengan mempertimbangkan hasil seleksi dan kelengkapan data,
maka calon peserta didik tersebut secara resmi 
<strong>DITERIMA</strong> sebagai peserta didik 
<strong>SMP & SMK UTAMA - Yayasan Pendidikan Putra Gumanti (YPPG)</strong>.
</p>
<?php } ?>


<!-- TTD -->
<table class="ttd">
<tr>
    <td width="60%"></td>
    <td>
        <?= date('d F Y') ?><br>
        Panitia PPDB<br><br><br>
        <u><?= $panitia['nama'] ?></u>
    </td>
</tr>
</table>

</body>
</html>
