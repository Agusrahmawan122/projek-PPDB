<!--
  PPDB UI Template (single-file HTML)
  - Sections: navbar (fixed), hero, profil, fasilitas, informasi, info pendaftaran, form pendaftaran (skeleton), invoice preview, kontak, footer
  - Self-contained CSS + small JS for nav active and form validation UI
  - Replace image paths in <img> and --hero-image-url with your assets
-->
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>PPDB - SMP-SMK UTAMA (UI Template)</title>
  <link rel="stylesheet" href="asset/css/bootstrap.min.css">
  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <style>
    :root{
      --blue:#2da8ff;
      --dark:#05204a;
      --muted:rgba(0,0,0,0.6);
      --white:#ffffff;
      --radius:16px;
      --container:1100px;
      --glass: rgba(255,255,255,0.12);
    }
    *{box-sizing:border-box}
    body{font-family:Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; margin:0; color:#222; line-height:1.45;background:#f5f8fb}
    a{color:inherit; text-decoration:none}

    /* NAVBAR */
    .navbar{position:fixed; top:0; left:0; right:0; height:70px; display:flex; align-items:center; justify-content:space-between; padding:0 24px; background:linear-gradient(180deg, rgba(255,255,255,0.96), rgba(255,255,255,0.92)); backdrop-filter: blur(6px); box-shadow:0 6px 18px rgba(12,34,60,0.08); z-index:1200}
    .nav-left{display:flex; align-items:center; gap:12px}
    .nav-left img{height:44px; width:44px; object-fit:cover; border-radius:8px}
    .brand{font-weight:700; font-size:18px; color:var(--dark)}
    .nav-links{display:flex; gap:12px; align-items:center}
    .nav-links a{padding:8px 12px; border-radius:10px; color:var(--muted); font-weight:600}
    .nav-links a.active, .nav-links a:hover{color:var(--blue); background:rgba(45,168,255,0.06)}
    .cta{background:var(--blue); color:var(--white); padding:8px 14px; border-radius:10px; font-weight:700}

    /* container helper */
    .container{max-width:var(--container); margin:0 auto; padding:0 20px}
    main{padding-top:92px}

    /* HERO */
    .hero{min-height:64vh; display:flex; align-items:center; position:relative; color:var(--white); overflow:hidden}
    .hero::before{content:""; position:absolute; inset:0; background-image:linear-gradient(180deg, rgba(5,32,74,0.6), rgba(5,32,74,0.35)), url('asset/img/gambar0.jpg'); background-size:cover; background-position:center; filter:brightness(0.9); z-index:0}
    .hero-inner{position:relative; z-index:2; padding:80px 0}
    .hero h1{font-size:40px; margin:0 0 12px; line-height:1.05}
    .hero p{max-width:760px; margin:0 0 20px; color:rgba(255,255,255,0.95)}
    .hero .actions{display:flex; gap:12px}
    .btn{display:inline-block; padding:12px 18px; border-radius:10px; font-weight:700}
    .btn-outline{background:transparent; color:var(--white); border:2px solid rgba(255,255,255,0.18)}
    .btn-primary{background:var(--blue); color:var(--white)}

    /* Profil section */
    section.profile{padding:48px 0}
    .profile .row{display:flex; gap:28px; align-items:center}
    .col{flex:1}
    .profile img{width:100%; border-radius:14px; box-shadow:0 8px 30px rgba(12,34,60,0.08)}
    .profile h2{margin:0 0 12px}

    /* Info cards (blue bg) */
    #informasi{background:var(--blue); color:var(--white); padding:36px 20px; border-radius:18px; margin:28px 0}
    .info-grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:18px}
    .info-card{background:rgba(255,255,255,0.12); padding:18px; border-radius:12px; box-shadow:inset 0 -1px 0 rgba(255,255,255,0.04)}
    .info-card h3{margin:0 0 8px; font-size:16px}

    /* Info pendaftaran */
    #infoPendaftaran{padding:28px 0}
    .steps{display:flex; gap:14px; flex-wrap:wrap}
    .step{flex:1; min-width:220px; background:#fff; padding:16px; border-radius:12px; box-shadow:0 8px 20px rgba(12,34,60,0.06)}
    .step h4{margin:0 0 8px}

    /* Form pendaftaran */
    .form-wrap{background:#fff; padding:22px; border-radius:12px; box-shadow:0 12px 40px rgba(12,34,60,0.06)}
    .form-grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:12px}
    label{display:block; font-size:14px; margin-bottom:6px; color:#203049}
    input[type=text], input[type=email], select, textarea, input[type=file]{width:100%; padding:10px; border-radius:8px; border:1px solid #e6eef8}
    textarea{min-height:110px}
    .muted{color:var(--muted); font-size:14px}

    /* Invoice preview */
    .invoice{background:#fff; padding:18px; border-radius:12px; box-shadow:0 8px 28px rgba(12,34,60,0.06)}
    .invoice .line{display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px dashed #eef5ff}
    .invoice .total{font-weight:800; font-size:18px}

    /* Contact */
    .contact{display:grid; grid-template-columns:1fr 320px; gap:20px}
    .map{height:220px; background:#e9f5ff; border-radius:12px}

    /* Footer */
    footer{padding:24px 0; text-align:center; color:var(--muted)}

    /* Responsive */
    @media (max-width:900px){
      .nav-links{display:none}
      .hero h1{font-size:28px}
      .contact{grid-template-columns:1fr}
    }
  </style>
</head>
<body>
  <div class="navbar container">
    <div class="nav-left">
      <img src="asset/icon/logo.webp" alt="logo">
      <div class="brand">SMP–SMK UTAMA</div>
    </div>

    <div class="nav-links" id="navLinks">
      <a href="#beranda" class="nav-link">Beranda</a>
      <a href="#profil" class="nav-link">Profil</a>
      <a href="#informasi" class="nav-link">Informasi</a>
      <a href="#pendaftaran" class="nav-link">Pendaftaran</a>
      <a href="#kontak" class="nav-link">Kontak</a>
      <a class="cta" href="#pendaftaran">Daftar Sekarang</a>
    </div>
  </div>

  <main>
    <!-- HERO -->
    <section class="hero" id="beranda">
      <div class="container hero-inner">
        <div style="max-width:760px">
          <h1>Selamat Datang di PPDB<br>SMP–SMK UTAMA</h1>
          <p>Daftarkan putra-putri Anda dengan mudah melalui sistem pendaftaran online yang aman dan terintegrasi. Semua data tersimpan otomatis, dengan proses pembayaran dan faktur digital.</p>
          <div class="actions">
            <a class="btn btn-primary" href="#pendaftaran">Daftar Sekarang</a>
            <a class="btn btn-outline" href="#informasi">Pelajari Lebih Lanjut</a>
          </div>
        </div>
      </div>
    </section>

    <!-- PROFIL -->
    <section class="profile container" id="profil">
      <div class="row">
        <div class="col">
          <h2>Profil Sekolah</h2>
          <p>SMP–SMK UTAMA berkomitmen memberikan pendidikan berkualitas dengan fasilitas lengkap, tenaga pendidik profesional, dan lingkungan yang mendukung perkembangan karakter siswa.</p>
          <p class="muted">Visi: Menjadi lembaga pendidikan unggul yang berkarakter dan berprestasi.</p>
        </div>
        <div class="col">
          <img src="asset/img/profil.jpg" alt="Profil Sekolah">
        </div>
      </div>
    </section>

    <!-- FASILITAS / INFORMASI -->
    <section class="container" id="informasi">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:18px;">
        <div>
          <h2 style="color:white;margin:0 0 8px">Informasi PPDB</h2>
          <p style="color:rgba(255,255,255,0.95); margin:0 0 10px">Informasi penting mengenai jadwal, persyaratan, dan biaya pendaftaran.</p>
        </div>
      </div>

      <div class="info-grid" style="margin-top:18px">
        <div class="info-card">
          <h3>📅 Jadwal</h3>
          <p>1 Juni - 31 Juli 2025 • Pengumuman 5 Agustus 2025</p>
        </div>
        <div class="info-card">
          <h3>📌 Persyaratan</h3>
          <p>KK, Akta Kelahiran, Pas Foto 3x4, Raport</p>
        </div>
        <div class="info-card">
          <h3>💰 Biaya</h3>
          <p>Pendaftaran: Rp 100.000 • Uang pangkal: Rp 1.000.000 • SPP: Rp 200.000/bln</p>
        </div>
        <div class="info-card">
          <h3>🧾 Cara Daftar</h3>
          <p>Isi formulir → Upload berkas → Terima invoice → Bayar → Upload bukti</p>
        </div>
      </div>
    </section>

    <!-- INFO PENDAFTARAN (steps) -->
    <section class="container" id="infoPendaftaran">
      <h2 style="margin-bottom:14px">Alur Pendaftaran</h2>
      <div class="steps">
        <div class="step">
          <h4>1. Lihat Informasi</h4>
          <p class="muted">Pelajari fasilitas, biaya, dan persyaratan di website.</p>
        </div>
        <div class="step">
          <h4>2. Isi Formulir</h4>
          <p class="muted">Lengkapi data calon siswa dan orang tua, upload dokumen.</p>
        </div>
        <div class="step">
          <h4>3. Terbitkan Invoice</h4>
          <p class="muted">Sistem otomatis membuat invoice tagihan biaya pendidikan.</p>
        </div>
        <div class="step">
          <h4>4. Pembayaran & Konfirmasi</h4>
          <p class="muted">Orang tua melakukan pembayaran dan upload bukti.</p>
        </div>
      </div>
    </section>

    <!-- FORM PENDAFTARAN (skeleton) -->
    <!-- ================= FORM PENDAFTARAN ================= -->
    <section id="pendaftaran" class="container py-5">
      <h2 class="text-center mb-4">Formulir Pendaftaran Peserta Didik Baru</h2>
      <p class="text-center mb-4">Silakan isi data dengan lengkap dan benar.</p>

      <form action="simpan_pendaftaran.php" method="POST" enctype="multipart/form-data" class="row g-3">

        <!-- ==================== DATA SISWA ==================== -->
        <h4 class="mt-4">Data Siswa</h4>

        <div class="col-md-6">
          <label class="form-label">Nama Lengkap *</label>
          <input type="text" name="nama_siswa" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">NIK Siswa *</label>
          <input type="text" name="nik_siswa" class="form-control" required>
        </div>

        <div class="col-md-4">
          <label class="form-label">Jenis Kelamin *</label>
          <select name="jk_siswa" class="form-select" required>
            <option value="">-- Pilih --</option>
            <option>Laki-laki</option>
            <option>Perempuan</option>
          </select>
        </div>

        <div class="col-md-4">
          <label class="form-label">Tempat Lahir *</label>
          <input type="text" name="tempat_lahir" class="form-control" required>
        </div>

        <div class="col-md-4">
          <label class="form-label">Tanggal Lahir *</label>
          <input type="date" name="tanggal_lahir" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Agama *</label>
          <select name="agama" class="form-select" required>
            <option value="">-- Pilih --</option>
            <option>Islam</option>
            <option>Kristen</option>
            <option>Katolik</option>
            <option>Hindu</option>
            <option>Buddha</option>
            <option>Konghucu</option>
          </select>
        </div>

        <div class="col-md-6">
          <label class="form-label">Anak Ke- *</label>
          <input type="number" min="1" name="anak_ke" class="form-control" required>
        </div>

        <div class="col-12">
          <label class="form-label">Alamat Lengkap *</label>
          <textarea name="alamat_siswa" class="form-control" rows="2" required></textarea>
        </div>


        <!-- ==================== DATA ORANG TUA ==================== -->
        <h4 class="mt-4">Data Orang Tua / Wali</h4>

        <div class="col-md-6">
          <label class="form-label">Nama Ayah *</label>
          <input type="text" name="nama_ayah" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Nama Ibu *</label>
          <input type="text" name="nama_ibu" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Pekerjaan Ayah *</label>
          <input type="text" name="pekerjaan_ayah" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Pekerjaan Ibu *</label>
          <input type="text" name="pekerjaan_ibu" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Nomor HP Ayah *</label>
          <input type="text" name="hp_ayah" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Nomor HP Ibu *</label>
          <input type="text" name="hp_ibu" class="form-control" required>
        </div>

        <div class="col-12">
          <label class="form-label">Alamat Orang Tua *</label>
          <textarea name="alamat_ortu" class="form-control" rows="2" required></textarea>
        </div>


        <!-- ==================== DATA ASAL SEKOLAH ==================== -->
        <h4 class="mt-4">Data Asal Sekolah</h4>

        <div class="col-md-6">
          <label class="form-label">Nama Sekolah Asal *</label>
          <input type="text" name="asal_sekolah" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">NPSN Sekolah Asal *</label>
          <input type="text" name="npsn" class="form-control" required>
        </div>

        <div class="col-md-12">
          <label class="form-label">Alamat Sekolah Asal *</label>
          <textarea name="alamat_asal_sekolah" class="form-control" rows="2" required></textarea>
        </div>


        <!-- ==================== BERKAS PENDAFTARAN ==================== -->
        <h4 class="mt-4">Upload Berkas Persyaratan</h4>

        <div class="col-md-6">
          <label class="form-label">Kartu Keluarga (KK) *</label>
          <input type="file" name="kk" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Akte Kelahiran *</label>
          <input type="file" name="akte" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Raport (Scan Nilai) *</label>
          <input type="file" name="raport" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Pas Foto (3x4) *</label>
          <input type="file" name="foto" class="form-control" required>
        </div>


        <!-- ==================== AKUN LOGIN ==================== -->
        <h4 class="mt-4">Buat Akun PPDB</h4>

        <div class="col-md-6">
          <label class="form-label">Email Aktif *</label>
          <input type="email" name="email" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Password *</label>
          <input type="password" name="password" class="form-control" required>
        </div>


        <!-- ==================== SUBMIT ==================== -->
        <div class="col-12 text-center mt-4">
          <button type="submit" class="btn btn-primary px-5 py-2">Kirim Pendaftaran</button>
        </div>

      </form>
    </section>


    <!-- CONTACT -->
    <section class="container" id="kontak" style="padding:24px 0">
      <h2>Kontak & Lokasi</h2>
      <div class="contact">
        <div>
          <p class="muted">Alamat: Jl. Pendidikan No.10, Kota Contoh</p>
          <div class="map">Google Maps iframe here</div>
        </div>
        <div>
          <div class="form-wrap">
            <h4>Kirim Pesan</h4>
            <label>Nama</label>
            <input type="text">
            <label>Email / WA</label>
            <input type="text">
            <label>Pesan</label>
            <textarea></textarea>
            <div style="margin-top:8px; text-align:right"><button class="btn btn-primary">Kirim</button></div>
          </div>
        </div>
      </div>
    </section>

    <footer class="container">
      <p style="margin:8px 0">© 2025 SMP–SMK UTAMA — Semua hak cipta dilindungi.</p>
    </footer>
  </main>

  <script>
    // Simple nav active on scroll / click
    const navLinks = document.querySelectorAll('.nav-links a');
    function setActive(hash){
      navLinks.forEach(a=>a.classList.toggle('active', a.getAttribute('href')===hash));
    }
    // click handler
    navLinks.forEach(a=> a.addEventListener('click', e=> setActive(a.getAttribute('href'))));
    // on load set based on location
    setActive(location.hash || '#beranda');

    // simple form submit demo (prevent actual submit)
    document.getElementById('formDaftar').addEventListener('submit', function(e){
      e.preventDefault();
      alert('Form pendaftaran terkirim. Sistem akan membuat nomor pendaftaran dan invoice. (Demo UI)');
      // here you would send form with fetch/ajax to backend endpoint
      this.reset();
    });
  </script>
</body>
</html>
