<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "web_ppdb";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
	die("Koneksi Gagal : ".mysqli_error());
}

?>