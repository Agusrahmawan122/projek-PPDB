<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB SMP-SMK UTAMA</title>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>	
	<style type="text/css">
  
* {
  margin: 0;
  padding: 0;
}

body {
  font-family:Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; 
  margin:0; 
  color:#222;
  background:#f5f8fb;
}

.konten {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 50%;
	background: white;
	border-radius: 5px;
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	gap: 50px;
	box-shadow: 0 8px 20px rgba(12,34,60,0.06);
}

.form {
	padding: 20px;
	color: rgba(0,0,0,0.6);
}
.form form {
	display: flex;
	flex-direction: column;
}

.ucapan {
	padding-bottom: 20px;
}
.ucapan h4 {
	font-size: 1.2em;
	display: flex;
	align-items: center;
	margin: 10px 0px;
}
.ucapan img {
	width: 50px;
	margin: 0px 10px;
}
.ucapan p {
	font-size: 0.9em;
}

.input {
	display: flex;
	align-items: center;
	border: 1px solid #2da8ff40;
	padding: 5px 10px;
	margin: 10px 0px;
	border-radius: 5px;
	box-shadow: 0px 0px 5px #2da8ff45;
}
.input:hover {
	background: rgba(45,168,255,0.06);
}
.input img {
	width: 30px;
}
.input input {
	width: -webkit-fill-available;
	padding: 5px;
	font-size: 0.9em;
	border: none;
	outline-style: none;
	color: rgba(0,0,0,0.6);
	background: transparent;
}

.btn-form {
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	gap: 20px;
	align-items: center;
	margin: 10px 0px;
}
.btn-form button {
	padding: 10px;
	border: none;
	outline-style: none;
	border-radius: 5px;
	background: #2da8ff;
	color: white;
	margin: 10px 0px;
	font-weight: bold;
	font-size: 0.9em;
}
.btn-form button:hover,
.btn-form a:hover {
	background: #0a58ca;
	transition: 0.5s all;
	cursor: pointer;
}
.btn-form a {
	text-decoration: none;
	padding: 10px;
	background: #2da8ff;
	border-radius: 5px;
	color: white;
	font-weight: bold;
	text-align: center;
	font-size: 0.9em;
}

#kembali {
	display: flex;
	align-items: center;
	text-decoration: none;
	font-size: 0.9em;
	justify-content: center;
	color: #2da8ff;
	margin: 10px 0px;
}
#kembali img {
	width: 20px;
	margin: 0px 10px;
}

.detail {
	background: #2da8ff1f;
	border-radius: 5px;
	padding: 20px;
	font-size: 0.9em;
	color: rgba(0,0,0,0.6);
	text-align: justify;
}
.detail img {
	width: 50px;
	margin: 20px 0px;
}

#pesanError {
	background: #ff00001c;
  padding: 5px 10px;
  border-radius: 5px;
  margin: 10px 0px;
  font-size: 0.9em;
}

#pesanSukses {
	background: #0080001c;
  padding: 5px 10px;
  border-radius: 5px;
  margin: 10px 0px;
  font-size: 0.9em;
}

@media only screen and (max-width: 990px) {
	.konten {
		width: 90%;
		display: flex;
		flex-direction: column-reverse;
		gap: 10px;
	}
	.form {
		height: fit-content;
		display: block;
	}
	.detail {
		display: block;
	}
}

</style>
</head>

<?php
	
include 'asset/config/koneksi.php';

if (isset($_POST['daftar'])) {
	$username = stripcslashes(strtolower($_POST['username']));

	$stmt = $koneksi->prepare("SELECT * FROM pengguna WHERE username = ?");
	$stmt->bind_param("s", $username);
	$stmt->execute();
	$result = $stmt->get_result();
	$data = $result->num_rows;

	if ($data > 0) {
	    $pesan_error = 'Username sudah digunakan!';
	} else {
		$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
		$role = 'pendaftar';
		$email = $_POST['email']?? '';

		$stmt2 = $koneksi->prepare("INSERT INTO pengguna (username, password, role, email) VALUES (?, ?, ?, ?)");
		$stmt2->bind_param("ssss", $username, $password, $role, $email);
		$stmt2->execute();

		$pesan_sukses = 'Pendaftaran Berhasil, Silahkan Login.';

	}

}

?>

<body>
	<div class="konten">
		<div class="form" data-aos="zoom-in" data-aos-duration="1500">
			<form action="" method="POST">
				<div class="ucapan">
					<h4>Selamat Datang <img src="asset/icon/hello2.png"></h4>
					<p>Silahkan buat akun baru untuk mendaftar PPDB.</p>
				</div>
				<?php if (!empty($pesan_error)): ?>
					<div class="pesan-error" id="pesanError"><?= htmlspecialchars($pesan_error) ?></div>
				<?php endif; ?>
				<?php if (!empty($pesan_sukses)): ?>
					<div class="pesan-sukses" id="pesanSukses"><?= htmlspecialchars($pesan_sukses) ?></div>
				<?php endif; ?>
				<div class="input">
					<img src="asset/icon/username.png">
					<input type="text" name="username" value="<?= $_POST['username']?? ''?>" placeholder="Username" required>
				</div>
				<div class="input">
					<img src="asset/icon/password.png">
					<input type="password" name="password" value="<?= $_POST['password']?? ''?>" placeholder="Password" required>
				</div>
				<div class="input">
					<img src="asset/icon/email3.png">
					<input type="email" name="email" value="<?= $_POST['email']?? ''?>" placeholder="E-mail">
				</div>
				<div class="btn-form">
					<button name="daftar">Daftar</button>
					<a href="login.php">Login</a>
				</div>
				<a href="index.php" id="kembali">
					<img src="asset/icon/back2.png">
					Kembali
				</a>
			</form>
		</div>
		<div class="detail" data-aos="zoom-in" data-aos-duration="1500">
			<img src="asset/icon/logo.webp">
			<p>PPDB Online SMP–SMK UTAMA menghadirkan sistem pendaftaran yang cepat, modern, dan terintegrasi. Semua proses—mulai dari pengisian formulir, unggah berkas, otomatis di server dan dapat dipantau secara real-time melalui dashboard sekolah.</p><br>
			<p><i>“Pendaftaran Mudah, Proses Transparan.”</i></p>
		</div>
	</div>
</body>
<script>
 AOS.init();

setTimeout(() => {
		const pesan = document.getElementById('pesanError');
		if (pesan) {
			pesan.style.display = 'none';
		}

		const pesan2 = document.getElementById('pesanSukses');
		if (pesan2) {
			pesan2.style.display = 'none';
		}

	}, 15000);
</script>
</html>