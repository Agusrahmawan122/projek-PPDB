<?php
include 'asset/config/koneksi.php';

// Proses insert
if(isset($_POST['submit'])){
    $konten = $_POST['konten']; // Ambil data dari input hidden

    $query = "INSERT INTO dokumen (isi) VALUES ('$konten')";
    $result = mysqli_query($koneksi, $query);

    if($result){
        echo "<script>alert('Data berhasil disimpan');</script>";
    } else {
        echo "<script>alert('Gagal menyimpan');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Dokumen</title>

    <!-- Quill CSS -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
</head>
<body>

<form method="POST">

    <!-- Area Editor -->
    <div id="editor" style="height: 300px;"></div>

    <!-- Hidden input untuk mengirim data ke PHP -->
    <input type="hidden" name="konten" id="konten">

    <button type="submit" name="submit">Simpan</button>
</form>

<!-- Quill JS -->
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

<script>
var quill = new Quill('#editor', {
    theme: 'snow'
});

// Saat submit, ambil isi editor (HTML) dan masukkan ke input hidden
document.querySelector('form').onsubmit = function() {
    let html = quill.root.innerHTML;
    document.getElementById('konten').value = html;
};
</script>

</body>
</html>
