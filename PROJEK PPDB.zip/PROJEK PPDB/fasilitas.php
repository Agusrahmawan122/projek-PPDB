<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Fasilitas Sekolah</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container py-5">
  <h2 class="fw-bold text-center mb-4">Fasilitas Sekolah</h2>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="card shadow-sm">
        <img src="img/lab.jpg" class="card-img-top">
        <div class="card-body">
          <h5>Laboratorium Modern</h5>
          <p>Lab komputer, IPA, dan multimedia lengkap.</p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm">
        <img src="img/kelas.jpg" class="card-img-top">
        <div class="card-body">
          <h5>Kelas Nyaman</h5>
          <p>Kelas full AC dengan LCD projector.</p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm">
        <img src="img/perpustakaan.jpg" class="card-img-top">
        <div class="card-body">
          <h5>Perpustakaan</h5>
          <p>Buku lengkap + reading corner modern.</p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
