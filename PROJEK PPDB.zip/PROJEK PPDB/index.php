<?php
include 'asset/config/koneksi.php';

$query = mysqli_query($koneksi, "SELECT * FROM halaman_utama LIMIT 1");
$data_halaman = mysqli_fetch_assoc($query);
$profil_awal = $data_halaman['profil'];
$biaya_awal = $data_halaman['biaya'];
$jadwal_awal = $data_halaman['jadwal'];
$persyaratan_awal = $data_halaman['syarat'];

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PPDB SMP-SMK UTAMA</title>
  <link rel="stylesheet" href="asset/css/bootstrap.min.css">
  <script src="asset/js/bootstrap.bundle.min.js"></script>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <link rel="stylesheet" type="text/css" href="asset/css2/index.css">
</head>
<body>

  <div class="navbar">
    <div class="kol1">
      <img src="asset/icon/logo.webp">
      <strong>SMP-SMK UTAMA</strong>
      <button id="btn-menu" style="background-image: url('asset/icon/menu2.png'); background-size: cover;"></button>
    </div>

    <div class="kol2">
      <a href="#beranda" class="active">Beranda</a>
      <a href="#profil">Profil</a>
      <a href="#informasi">Informasi</a>
      <a href="#kontak">Kontak</a>
      <a href="daftar.php" style="background-color: #2da8ff; color: white;">Daftar</a>
    </div>
  </div>

  <div class="beranda" id="beranda" data-aos="zoom-in-up" data-aos-duration="1500">
    <div class="text-beranda">
      <h1>Selamat Datang di PPDB<br>SMP–SMK UTAMA</h1>
      <p>Daftarkan putra-putri Anda dengan mudah melalui sistem pendaftaran online yang aman dan terintegrasi. Semua data tersimpan otomatis.</p>
      <a href="daftar.php">Daftar Sekarang</a>
    </div>
  </div>

  <div class="profil" id="profil" data-aos="fade-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine"
     data-aos-duration="1500">
    <div class="konten-profil">
      <div class="text-profil">
        <h2>Profil Sekolah</h2>
        <?= $profil_awal ?>
      </div>
      <div class="img-profil" data-aos="fade-zoom-in" data-aos-easing="ease-in-back" data-aos-duration="1500">
        <img src="asset/img/gambar1.jpg" alt="Profil Sekolah">
      </div>
    </div>
  </div>

  <div class="informasi" id="informasi">
    <div class="konten-informasi" data-aos="fade-left"
     data-aos-anchor-placement="top-bottom" data-aos-duration="1500">
      <div class="text-informasi">
        <h2>Informasi PPDB</h2>
        <p>Informasi penting mengenai jadwal, persyaratan, dan biaya pendaftaran.</p>
      </div>
      <div class="card-informasi">
        <div class="card">
          <h5>📅 Jadwal</h5>
          <?= $jadwal_awal ?>
        </div>
        <div class="card">
          <h5>📌 Persyaratan</h5>
          <?= $persyaratan_awal ?>
        </div>
        <div class="card">
          <h5>💰 Biaya</h5>
          <?= $biaya_awal ?>
        </div>
      </div>
    </div>
  </div>

  <div class="alur-daftar" id="alur-daftar" data-aos="zoom-in" data-aos-duration="1500">
    <div class="konten-alur">
      <div class="text-alur">
        <h2>Alur Pendaftaran</h2>
      </div>
      <div class="cards-alur">
        <div class="card-alur">
          <strong>1. Lihat Informasi</strong>
          <p>Pelajari biaya, dan persyaratan di website.</p>
        </div>
        <div class="card-alur">
          <strong>2. Buat Akun</strong>
          <p>Buat akun PPDB untuk siswa dengan klik daftar.</p>
        </div>
        <div class="card-alur">
          <strong>3. Daftar PPDB</strong>
          <p>Masuk ke akun dan klik menu PPDB.</p>
        </div>
        <div class="card-alur">
          <strong>4. Isi Formulir</strong>
          <p>Isi Formulir dan lengkapi data.</p>
        </div>
        <div class="card-alur">
          <strong>5. Terbitkan Invoice</strong>
          <p>Sistem akan otomatis menerbitkan invoice pendaftaran.</p>
        </div>
      </div>
    </div>
  </div>

  <div class="kontak" id="kontak">
    <div class="konten-kontak" data-aos="zoom-out" data-aos-duration="1500">
      <h2>Kontak & Lokasi</h2>
      <div class="cards-kontak">
        <div class="maps">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.0054361992597!2d106.73811847603801!3d-6.26301296131776!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f14d6b9d6ed3%3A0xc3cc5c840568d08b!2sSMP%20%26%20SMK%20UTAMA%20-%20Yayasan%20Pendidikan%20Putra%20Gumanti%20(YPPG)!5e0!3m2!1sid!2sid!4v1764677846489!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="data-kontak">
          <p><img src="asset/icon/map2.png"> Alamat: <?= $data_halaman['alamat']?></p>
          <p><img src="asset/icon/telepon2.png"> Telepon: <?= $data_halaman['telepon']?></p>
          <p><img src="asset/icon/wa2.png"> WhatsApp PPDB: <?= $data_halaman['wa']?></p>
          <p><img src="asset/icon/email2.png"> Email: <?= $data_halaman['email']?></p>
          <p><img src="asset/icon/time.png"> Jam layanan: <?= $data_halaman['jam']?></p>
          <p><strong>Sosial Media</strong></p>
          <div class="sosmed">
            <a href="<?= $data_halaman['link_fb']?>">
              <img src="asset/icon/fb2.png">
              <p id="nama-smd">Facebook</p>
            </a>
            <a href="<?= $data_halaman['link_ig']?>">
              <img src="asset/icon/ig2.png">
              <p id="nama-smd">Instagram</p>
            </a>
            <a href="<?= $data_halaman['link_yt']?>">
              <img src="asset/icon/yt2.png">
              <p id="nama-smd">YouTube</p>
            </a>
            <a href="<?= $data_halaman['link_tk']?>">
              <img src="asset/icon/tiktok2.png">
              <p id="nama-smd">TikTok</p>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div>
    
  </div>

</body>

<script>
  AOS.init();
</script>

<script>
document.getElementById("btn-menu").addEventListener("click", function () {
    const kol2 = document.querySelector(".kol2");

    if (kol2.style.display === "none" || kol2.style.display === "") {
        kol2.style.display = "block";
    } 
    else {
        kol2.style.display = "none";
    }
});

  const menuLinks = document.querySelectorAll(".kol2 a");

  menuLinks.forEach(link => {
    link.addEventListener("click", function() {

      // Hapus active dari semua menu
      menuLinks.forEach(l => l.classList.remove("active"));

      // Tambahkan active ke menu yang diklik
      this.classList.add("active");
    });
  });
</script>


</html>