<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PPDB</title>
	<style type="text/css">
* {
	padding: 0;
	margin: 0;
}

body {
	font-family: Poppins, Roboto, "Open Sans", "Helvetica Neue", Arial, sans-serif;
    background: whitesmoke;
    display: flex;
    justify-content: center;
    padding: 20px 0px;
}

.box {
	background: white;
	width: 80%;
	height: fit-content;
	padding: 20px;
	border-radius: 5px;
}

.form form {
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	gap: 20px;
	align-items: center;
}

.form1 {
	width: 100%;
	display: flex;
	flex-direction: column;
	margin: 20px 0px;
}
.input label {
	width: 250px;
	display: inline-block;
	font-size: 0.9em;
}
.input input,
.input select,
.input textarea {
	padding: 8px 10px;
	font-size: 0.9em;
	resize: none;
	width: -webkit-fill-available;
	margin: 10px 0px;
	outline-style: none;
	border: 1px solid #0078ff40;
	border-radius: 5px;
}
.input input:hover,
.input select:hover,
.input textarea:hover {
	background: #0078ff17;
	box-shadow: 0px 0px 5px #0078ff45;
	transition: 0.5s all;
}

.input input[type="date"],
.input textarea {
	font-size: 1.2em;
}

.form2 {
	width: 100%;
}

	</style>
</head>
<body>
	<div class="box">
		<h3>Form Pendaftaran PPDB</h3>
		<div class="form">
			<form action="" method="POST">
				<div class="form1">
					<div class="input">
						<label>Nama Lengkap</label>
						<input type="text" name="nama">
					</div>
					<div class="input">
						<label>NISN</label>
						<input type="text" name="nisn">
					</div>
					<div class="input">
						<label>Jenis Kelamin</label>
						<select name="gender">
							<option value="<?= $_POST['gender'] ?? '' ?>"><?= $_POST['gender'] ?? '-- Pilih Jenis Kelamin --' ?></option>
							<option value="laki - laki">Laki - Laki</option>
							<option value="perempuan">Perempuan</option>
						</select>
					</div>
					<div class="input">
						<label>Tempat, Tanggal Lahir</label>
						<div style="display: flex; justify-content: space-between;">
							<input type="text" style="width: 45%;" name="tempat">
							<input type="date" style="width: 45%;" name="tanggal_lahir">
						</div>
					</div>
					<div class="input">
						<label>Agama</label><br>
						<div style="display: inline-flex; align-items: center; margin: 10px 0px;">
						<?php
							$agama = ["islam", "Buddha", "Hindu", "Kristen"];

							foreach ($agama as $ag) { ?>
								<input type="radio" name="agama" style="margin: 0px 10px;" value="<?= $ag ?>"><?= $ag ?>
							<?php }
						?>
						</div>
					</div>
					<div class="input">
						<label>Alamat Lengkap</label>
						<textarea name="alamat" rows="3"></textarea>
					</div>
					<div class="input">
						<label>Asal Sekolah</label>
						<input type="text" name="asal">
					</div>
					<div class="input">
						<label>Alamat Asal Sekolah</label>
						<textarea name="alamat_asal" rows="3"></textarea>
					</div>
					<div class="input">
						<label>Nomor Ijazah / SKL (opsional)</label>
						<input type="text" name="no_ijazah">
					</div>
					<div class="input">
						<label>Nomor HP Siswa (opsional)</label>
						<input type="text" name="no_hp_siswa">
					</div>
					<div class="input">
						<label>Email Siswa (opsional)</label>
						<input type="email" name="email_siswa">
					</div>
				</div>
				<div class="form2">
					<div class="input">
						<label>Nama Lengkap</label>
						<input type="text" name="nama">
					</div>
					<div class="input">
						<label>NISN</label>
						<input type="text" name="nisn">
					</div>
					<div class="input">
						<label>Jenis Kelamin</label>
						<select name="gender">
							<option value="<?= $_POST['gender'] ?? '' ?>"><?= $_POST['gender'] ?? '-- Pilih Jenis Kelamin --' ?></option>
							<option value="laki - laki">Laki - Laki</option>
							<option value="perempuan">Perempuan</option>
						</select>
					</div>
					<div class="input">
						<label>Tempat, Tanggal Lahir</label>
						<input type="text" name="tempat">
						<input type="date" name="tanggal_lahir">
					</div>
					<div class="input">
						<label>Agama</label><br>
						<div style="display: inline-flex; align-items: center; margin: 10px 0px;">
						<?php
							$agama = ["islam", "Buddha", "Hindu", "Kristen"];

							foreach ($agama as $ag) { ?>
								<input type="radio" name="agama" style="margin: 0px 10px;" value="<?= $ag ?>"><?= $ag ?>
							<?php }
						?>
						</div>
					</div>
					<div class="input">
						<label>Alamat Lengkap</label>
						<textarea name="alamat" rows="3"></textarea>
					</div>
					<div class="input">
						<label>Asal Sekolah</label>
						<input type="text" name="asal">
					</div>
					<div class="input">
						<label>Alamat Asal Sekolah</label>
						<input type="text" name="alamat_asal">
					</div>
					<div class="input">
						<label>Nomor Ijazah / SKL (opsional)</label>
						<input type="text" name="no_ijazah">
					</div>
					<div class="input">
						<label>Nomor HP Siswa (opsional)</label>
						<input type="text" name="no_hp_siswa">
					</div>
					<div class="input">
						<label>Email Siswa (opsional)</label>
						<input type="email" name="email_siswa">
					</div>
				</div>
			</form>
		</div>
	</div>
</body>
</html>