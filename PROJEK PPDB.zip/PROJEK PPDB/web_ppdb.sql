-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Des 2025 pada 16.42
-- Versi server: 10.4.19-MariaDB
-- Versi PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_ppdb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alur_ppdb`
--

CREATE TABLE `alur_ppdb` (
  `id` int(11) NOT NULL,
  `alur` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `alur_ppdb`
--

INSERT INTO `alur_ppdb` (`id`, `alur`) VALUES
(1, '1. Melihat Informasi Sekolah'),
(2, '2. Mengisi Formulir Pendaftaran'),
(3, '3. Verifikasi Berkas'),
(4, '4. Mendapat Tagihan Biaya'),
(5, '5. Melakukan Pembayaran'),
(6, '6. Mendapat Faktur & Konfirmasi'),
(7, '7. Daftar Ulang ke Sekolah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `biaya_ppdb`
--

CREATE TABLE `biaya_ppdb` (
  `id` int(11) NOT NULL,
  `biaya` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `biaya_ppdb`
--

INSERT INTO `biaya_ppdb` (`id`, `biaya`) VALUES
(1, '- SPP bulanan: Rp 200.000'),
(2, '- Uang pangkal: Rp 1.000.000'),
(3, '- Seragam lengkap: Rp 650.000'),
(4, '- Buku paket & perlengkapan belajar: Rp 450.000'),
(5, '- Kegiatan OSIS & ekstrakurikuler: Rp 100.000'),
(6, '- Biaya pendaftaran: Rp 100.000'),
(7, '- Daftar ulang (administrasi): Rp 150.000'),
(8, '- Study tour / kegiatan luar sekolah (opsional): Rp 300.000 – Rp 600.000'),
(9, '- Ujian semester: Rp 75.000 / semester');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_ppdb`
--

CREATE TABLE `jadwal_ppdb` (
  `id` int(11) NOT NULL,
  `jadwal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jadwal_ppdb`
--

INSERT INTO `jadwal_ppdb` (`id`, `jadwal`) VALUES
(1, 'Dibuka mulai 1 Januari – 30 Juni 2025.'),
(2, 'Seleksi akan dijadwalkan setelah pendaftaran.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kontak`
--

CREATE TABLE `kontak` (
  `id` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `wa` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jam` varchar(100) NOT NULL,
  `maps` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kontak`
--

INSERT INTO `kontak` (`id`, `alamat`, `telepon`, `wa`, `email`, `jam`, `maps`) VALUES
(1, 'Jl. Pendidikan No. 10, Tangerang Selatan', '(021) 7788-1234', '0812-3456-7890', 'ppdb@smpsmkutama.sch.id', 'Senin–Jumat, 08.00–15.00', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.0054361992597!2d106.73811847603801!3d-6.26301296131776!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f14d6b9d6ed3%3A0xc3cc5c840568d08b!2sSMP%20%26%20SMK%20UTAMA%20-%20Yayasan%20Pendidikan%20Putra%20Gumanti%20(YPPG)!5e0!3m2!1sid!2sid!4v1764677846489!5m2!1sid!2sid\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','pendaftar') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$f4r69QGOLSAX3HA2HOLlyOYhSxe9lNAnNKeR5osv8wmy785Z7AUX6', 'admin'),
(2, 'agus', '$2y$10$f4r69QGOLSAX3HA2HOLlyOYhSxe9lNAnNKeR5osv8wmy785Z7AUX6', 'pendaftar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `profil`
--

CREATE TABLE `profil` (
  `id` int(11) NOT NULL,
  `profil` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `profil`
--

INSERT INTO `profil` (`id`, `profil`) VALUES
(1, 'SMP-SMK UTAMA adalah lembaga pendidikan yang berkomitmen untuk membentuk generasi berprestasi, berkarakter, dan siap menghadapi tantangan masa depan. Dengan dukungan tenaga pendidik profesional serta fasilitas yang memadai, kami menghadirkan lingkungan belajar yang aman, nyaman, dan menyenangkan bagi semua peserta didik.'),
(2, 'Kami terus berinovasi dalam pengembangan kurikulum dan kegiatan pembelajaran agar dapat memberikan pengalaman pendidikan terbaik bagi siswa.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sosmed`
--

CREATE TABLE `sosmed` (
  `id` int(11) NOT NULL,
  `fb` text DEFAULT NULL,
  `ig` text DEFAULT NULL,
  `yt` text DEFAULT NULL,
  `tiktok` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `sosmed`
--

INSERT INTO `sosmed` (`id`, `fb`, `ig`, `yt`, `tiktok`) VALUES
(1, NULL, 'https://www.instagram.com/?hl=en', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `syarat_ppdb`
--

CREATE TABLE `syarat_ppdb` (
  `id` int(11) NOT NULL,
  `syarat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `syarat_ppdb`
--

INSERT INTO `syarat_ppdb` (`id`, `syarat`) VALUES
(1, '- Mengisi formulir pendaftaran secara lengkap.'),
(2, '- Melampirkan fotokopi KTP/Kartu Pelajar.'),
(3, '- Melampirkan pas foto terbaru ukuran 3×4 sebanyak 2 lembar.'),
(4, '- Membayar biaya pendaftaran.'),
(5, '- Menyerahkan fotokopi ijazah terakhir atau surat keterangan lulus.'),
(6, '- Menyerahkan fotokopi kartu keluarga (KK).'),
(7, '- Mengikuti tes wawancara atau seleksi masuk (jika ada).');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alur_ppdb`
--
ALTER TABLE `alur_ppdb`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `biaya_ppdb`
--
ALTER TABLE `biaya_ppdb`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jadwal_ppdb`
--
ALTER TABLE `jadwal_ppdb`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `profil`
--
ALTER TABLE `profil`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sosmed`
--
ALTER TABLE `sosmed`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `syarat_ppdb`
--
ALTER TABLE `syarat_ppdb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alur_ppdb`
--
ALTER TABLE `alur_ppdb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `biaya_ppdb`
--
ALTER TABLE `biaya_ppdb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `jadwal_ppdb`
--
ALTER TABLE `jadwal_ppdb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `profil`
--
ALTER TABLE `profil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `sosmed`
--
ALTER TABLE `sosmed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `syarat_ppdb`
--
ALTER TABLE `syarat_ppdb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
